// DIGITAL SPARK WEB — Standalone Script
const DEMO_ITEMS = [
  { id: 'restaurant', title: 'Restaurant Website', filter: 'Food', desc: 'Boutique fine dining layout with curated menu and direct WhatsApp reservations.' },
  { id: 'ecommerce', title: 'Online Shopping Website', filter: 'Shopping', desc: 'High-end product showcase for fragrances, fashion, and luxury jewelry.' },
  { id: 'real-estate', title: 'Real Estate Website', filter: 'Property', desc: 'Prime architectural property presentations, floor plans, and agent booking.' },
  { id: 'interior', title: 'Interior Design Website', filter: 'Interior Design', desc: 'Sophisticated interior portfolio with residential and commercial showcases.' },
  { id: 'hotel', title: 'Hotel and Travel Website', filter: 'Services', desc: 'Resort and luxury stay layout with suite highlights and booking inquiries.' },
  { id: 'salon', title: 'Beauty Salon Website', filter: 'Services', desc: 'Aesthetic beauty studio menu, treatment pricing, and stylist portfolios.' },
  { id: 'corporate', title: 'Corporate Business Website', filter: 'Business', desc: 'Authoritative corporate presentation for advisory and consulting firms.' },
  { id: 'portfolio', title: 'Personal Portfolio Website', filter: 'Personal', desc: 'Bespoke portfolio for independent freelancers, creators, and engineers.' },
  { id: 'fitness', title: 'Fitness and Gym Website', filter: 'Services', desc: 'High-energy studio layout with training programs, coaches, and trials.' },
  { id: 'construction', title: 'Construction Website', filter: 'Business', desc: 'Civil engineering and contractor showcase highlighting builds and machinery.' },
  { id: 'education', title: 'Education Website', filter: 'Services', desc: 'Modern academic institution portal with syllabus details and admissions.' },
  { id: 'medical', title: 'Medical Clinic Website', filter: 'Services', desc: 'Trustworthy clinic presentation with doctor profiles and appointment schedules.' }
];

function renderGallery(filter = 'All') {
  const container = document.getElementById('galleryContainer');
  if (!container) return;

  const items = (filter === 'All') 
    ? DEMO_ITEMS 
    : DEMO_ITEMS.filter(item => item.filter === filter);

  container.innerHTML = items.map(item => `
    <div class="card gallery-card">
      <div>
        <div class="gallery-thumb">
          <span class="category-tag">${item.filter}</span>
          <div style="font-family:'Cormorant Garamond',serif;font-size:24px;color:#D9AD62;text-align:center;padding:10px;">${item.title}</div>
        </div>
        <h3 style="font-size:20px;margin-bottom:8px;">${item.title}</h3>
        <p style="font-size:13px;color:#999;margin-bottom:16px;">${item.desc}</p>
      </div>
      <div class="card-actions">
        <button class="btn btn-sm btn-outline" onclick="selectOrderCategory('${item.title}')">Order This Design</button>
      </div>
    </div>
  `).join('');
}

function filterGallery(category) {
  // Update buttons
  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(btn => {
    if (btn.innerText.includes(category) || (category === 'All' && btn.innerText.includes('All'))) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  renderGallery(category);
  const el = document.getElementById('gallery');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function selectOrderCategory(cat) {
  const select = document.getElementById('businessCategory');
  if (select) select.value = cat;
  const el = document.getElementById('order');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function selectPackage(name, price) {
  const select = document.getElementById('packageSelect');
  if (select) select.value = name;
  updatePrice();
  const el = document.getElementById('order');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function updatePrice() {
  const select = document.getElementById('packageSelect');
  const priceInput = document.getElementById('designPrice');
  if (!select || !priceInput) return;
  if (select.value === 'Normal') priceInput.value = 'PKR 3,000';
  else if (select.value === 'Premium') priceInput.value = 'PKR 4,500';
  else priceInput.value = 'PKR 6,000';
}

function toggleDuration() {
  const pub = document.getElementById('publishingOption').value;
  const group = document.getElementById('durationGroup');
  if (group) {
    group.style.display = (pub === 'I Need Live Publishing') ? 'block' : 'none';
  }
}

function discussPublishing() {
  const pub = document.getElementById('publishingOption');
  if (pub) pub.value = 'I Need Live Publishing';
  toggleDuration();
  const el = document.getElementById('order');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function submitWhatsApp(e) {
  e.preventDefault();
  const name = document.getElementById('fullName').value;
  const phone = document.getElementById('whatsappNum').value;
  const business = document.getElementById('businessName').value;
  const category = document.getElementById('businessCategory').value;
  const pkg = document.getElementById('packageSelect').value;
  const price = document.getElementById('designPrice').value;
  const pub = document.getElementById('publishingOption').value;
  const duration = document.getElementById('publishingDuration') ? document.getElementById('publishingDuration').value : '';
  const req = document.getElementById('requirements').value;
  const notes = document.getElementById('notes').value;

  const msg = "*NEW WEBSITE PROJECT ORDER — DIGITAL SPARK WEB*\\n\\n" +
    "👤 *Client Name:* " + name + "\\n" +
    "📱 *WhatsApp:* " + phone + "\\n" +
    "🏢 *Business Name:* " + business + "\\n" +
    "🏷️ *Category:* " + category + "\\n\\n" +
    "📦 *Package:* " + pkg + " (" + price + ")\\n" +
    "🌐 *Publishing:* " + pub + "\\n" +
    (pub === 'I Need Live Publishing' ? ("⏱️ *Duration:* " + duration + "\\n") : "") +
    "\\n📝 *Requirements:*\\n" + (req || "Standard responsive website.") + "\\n\\n" +
    (notes ? ("📌 *Notes:*\\n" + notes) : "");

  const agencyPhone = "923045768929";
  const url = "https://wa.me/" + agencyPhone + "?text=" + encodeURIComponent(msg);
  window.open(url, '_blank');
}

// Initial render
document.addEventListener('DOMContentLoaded', () => {
  renderGallery('All');
});
