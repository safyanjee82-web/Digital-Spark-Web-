# DIGITAL SPARK WEB — Premium Website Design Agency
## Standalone Static Package

A luxury black-and-gold website design agency website for DIGITAL SPARK WEB.

### Project Structure
```
digital-spark-web/
├── index.html       # Complete HTML5 structure
├── style.css        # Pure CSS3 styling (black and gold aesthetic)
├── script.js        # Vanilla JavaScript (filters, price calculation, WhatsApp router)
└── README.md        # Documentation and deployment instructions
```

### Key Features
1. **Zero Dependencies**: Pure HTML5, CSS3, and Vanilla JavaScript. Runs directly in any web browser without Node.js or a build step.
2. **Luxury Black & Gold Aesthetics**: Inspired by high-end architectural and interior design portfolios.
3. **Interactive 12-Industry Demonstration Gallery**: Fast client-side category filtering (Business, Shopping, Food, Property, Interior Design, Personal, Services).
4. **Three Design Packages**:
   - NORMAL: PKR 3,000
   - PREMIUM: PKR 4,500
   - BUSINESS: PKR 6,000
5. **Live Publishing Consultations**: Clear guidance that hosting and domain costs are quoted separately.
6. **Direct WhatsApp Integration**: Formats all customer specifications and launches a direct WhatsApp chat with the design consultant.

### How to Run Locally
Double-click `index.html` to open it in Google Chrome, Microsoft Edge, Safari, or Firefox.

### Deployment Options
- **Netlify / Vercel**: Drag and drop the `digital-spark-web` folder for instant global HTTPS hosting.
- **GitHub Pages**: Push this directory to a repository and enable GitHub Pages in settings.
- **Hostinger / cPanel**: Upload files to `public_html`.
