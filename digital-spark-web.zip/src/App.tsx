import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { StatsBar } from './components/StatsBar';
import { FeaturedProjects } from './components/FeaturedProjects';
import { Gallery } from './components/Gallery';
import { Pricing } from './components/Pricing';
import { PublishingSection } from './components/PublishingSection';
import { OrderForm } from './components/OrderForm';
import { ClosingCTA } from './components/ClosingCTA';
import { Footer } from './components/Footer';
import { PreviewModal } from './components/PreviewModal';
import { ExportModal } from './components/ExportModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { CategoryItem, PricingPackage } from './data/mockData';

export default function App() {
  const [previewItem, setPreviewItem] = useState<CategoryItem | null>(null);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [galleryFilter, setGalleryFilter] = useState('All Designs');

  // Form states to pass to OrderForm
  const [selectedCategory, setSelectedCategory] = useState<string>('Corporate Business');
  const [selectedPackage, setSelectedPackage] = useState<'normal' | 'premium' | 'business'>('business');
  const [selectedPublishing, setSelectedPublishing] = useState<string>('Website Design Only');

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExploreHero = () => {
    scrollTo('gallery');
  };

  const handleRequestQuote = () => {
    scrollTo('order-form');
  };

  const handleExploreService = (filter: string) => {
    setGalleryFilter(filter);
    scrollTo('gallery');
  };

  const handleOrderService = (category: string) => {
    setSelectedCategory(category);
    scrollTo('order-form');
  };

  const handleSelectPackage = (pkg: PricingPackage) => {
    setSelectedPackage(pkg.id);
    scrollTo('order-form');
  };

  const handleDiscussPublishing = () => {
    setSelectedPublishing('I Need Live Publishing');
    scrollTo('order-form');
  };

  return (
    <div className="min-h-screen bg-[#080808] text-[#BDBDBD] font-sans selection:bg-[#D9AD62]/20 selection:text-[#F4D79B]">
      {/* Navigation Header */}
      <Header
        onOrderClick={() => scrollTo('order-form')}
        onExportClick={() => setExportModalOpen(true)}
      />

      {/* Main Content Flow */}
      <main>
        {/* Cinematic Luxury Hero */}
        <Hero
          onExploreClick={handleExploreHero}
          onRequestQuoteClick={handleRequestQuote}
        />

        {/* Services Section with 4 Cards matching reference */}
        <Services
          onExploreService={handleExploreService}
          onOrderService={handleOrderService}
        />

        {/* Featured Projects with 3 Large Cards */}
        <FeaturedProjects
          onExploreConcept={(category) => {
            setSelectedCategory(category);
            scrollTo('order-form');
          }}
        />

        {/* Agency Statistics Bar matching reference */}
        <StatsBar />

        {/* 12-Industry Demonstration Gallery with filtering */}
        <Gallery
          onPreview={(item) => setPreviewItem(item)}
          onOrderDesign={(cat) => {
            setSelectedCategory(cat);
            scrollTo('order-form');
          }}
          activeFilter={galleryFilter}
        />

        {/* Fixed 3-Package Pricing: PKR 3000 / 4500 / 6000 */}
        <Pricing
          onSelectPackage={handleSelectPackage}
          selectedPackageId={selectedPackage}
        />

        {/* Optional Live Publishing Consultation */}
        <PublishingSection
          onDiscussPublishing={handleDiscussPublishing}
        />

        {/* Complete 10-Field Order Form with WhatsApp Routing */}
        <OrderForm
          initialCategory={selectedCategory}
          initialPackage={selectedPackage}
          initialPublishing={selectedPublishing}
        />

        {/* Closing CTA with prominent gold button and cursive script */}
        <ClosingCTA
          onStartClick={() => scrollTo('order-form')}
        />
      </main>

      {/* Luxury Footer */}
      <Footer />

      {/* Modal Dialogs */}
      <PreviewModal
        item={previewItem}
        onClose={() => setPreviewItem(null)}
        onOrderThis={(cat) => {
          setSelectedCategory(cat);
          scrollTo('order-form');
        }}
      />

      <ExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
      />

      {/* Fixed Floating WhatsApp Button pinned in corner */}
      <FloatingWhatsApp />
    </div>
  );
}
