export interface CategoryItem {
  id: string;
  title: string;
  filter: 'Business' | 'Shopping' | 'Food' | 'Property' | 'Interior Design' | 'Personal' | 'Services';
  shortDesc: string;
  fullDesc: string;
  image: string;
  badge: string;
  pages: string[];
  keyFeatures: string[];
}

export interface PricingPackage {
  id: 'normal' | 'premium' | 'business';
  name: string;
  price: number;
  formattedPrice: string;
  description: string;
  popular?: boolean;
  features: string[];
}

export const SERVICES = [
  {
    id: 'business',
    title: 'Business Website Design',
    category: 'Corporate Business Website',
    filterTag: 'Business',
    description: 'Professional website layouts for startups and growing businesses looking to build credibility.',
    icon: 'Briefcase',
  },
  {
    id: 'ecommerce',
    title: 'Online Store Design',
    category: 'Online Shopping Website',
    filterTag: 'Shopping',
    description: 'Attractive product presentation layouts and showcase catalogs for modern shopping brands.',
    icon: 'ShoppingBag',
  },
  {
    id: 'restaurant',
    title: 'Restaurant Website Design',
    category: 'Restaurant Website',
    filterTag: 'Food',
    description: 'Beautiful restaurant layouts featuring digital menus, food photography, and reservation contacts.',
    icon: 'Utensils',
  },
  {
    id: 'portfolio',
    title: 'Portfolio Website Design',
    category: 'Personal Portfolio Website',
    filterTag: 'Personal',
    description: 'Bespoke portfolios for freelancers, photographers, designers, and creative service providers.',
    icon: 'Sparkles',
  },
];

export const GALLERY_ITEMS: CategoryItem[] = [
  {
    id: 'restaurant',
    title: 'Restaurant Website',
    filter: 'Food',
    shortDesc: 'Atmospheric dining website with curated digital menu, reservations, and culinary photography.',
    fullDesc: 'Designed for boutique restaurants, cafes, and fine dining lounges. Features rich dark photography showcase, sectioned menu layout, chef profile, and direct WhatsApp table reservation link.',
    image: '/src/assets/images/demo_restaurant_luxury_1792820173991.jpg',
    badge: 'Fine Dining Concept',
    pages: ['Hero & Ambience', 'Curated Menu', 'Chef Story', 'Reservation / WhatsApp'],
    keyFeatures: ['Interactive Menu Filter', 'Gold Accented Typography', 'Mobile Optimized Tables']
  },
  {
    id: 'ecommerce',
    title: 'Online Shopping Website',
    filter: 'Shopping',
    shortDesc: 'Luxury product catalog presentation with item showcases and WhatsApp direct ordering.',
    fullDesc: 'Ideal for boutique apparel, perfumes, jewelry, and artisanal crafts. Features sleek product grid cards, multi-angle product zoom, specification accordions, and instant WhatsApp inquiry.',
    image: '/src/assets/images/demo_ecommerce_store_1792820174086.jpg',
    badge: 'Luxury Boutique Concept',
    pages: ['Collection Hero', 'Product Grid', 'Lookbook', 'Direct WhatsApp Checkout'],
    keyFeatures: ['Item Variant Selector', 'High-res Product Zoom', 'Zero-friction WhatsApp buy']
  },
  {
    id: 'real-estate',
    title: 'Real Estate Website',
    filter: 'Property',
    shortDesc: 'High-end property showcase presenting prime residences, floor plans, and agent consultations.',
    fullDesc: 'Crafted for real estate agencies, property brokers, and luxury housing developers. Features property photo sliders, dimension highlights, location overview, and quick inquiry buttons.',
    image: '/public/assets/aistudio/e85055f2866590bbd42562d44898c5c0_3d21485a.jpg',
    badge: 'Prime Real Estate',
    pages: ['Property Showcase', 'Floor Plans', 'Neighborhood Highlights', 'Private Tour Booking'],
    keyFeatures: ['Interactive Spec Cards', 'Floor Plan Visualizer', 'Agent WhatsApp Connect']
  },
  {
    id: 'interior',
    title: 'Interior Design Website',
    filter: 'Interior Design',
    shortDesc: 'Aesthetic architectural portfolio displaying bespoke residential and commercial spaces.',
    fullDesc: 'Directly inspired by luxury architectural studios. Features full-bleed project photo cards, design philosophy, before/after transformations, and consultation booking.',
    image: '/public/assets/aistudio/e85055f2866590bbd42562d44898c5c0_3d21485a.jpg',
    badge: 'Architectural Luxury',
    pages: ['Living Spaces', 'Commercial Projects', 'Material Palette', 'Consultation Inquiry'],
    keyFeatures: ['Full-bleed Photography', 'Subtle Gold Dividers', 'Project Details Modal']
  },
  {
    id: 'hotel',
    title: 'Hotel and Travel Website',
    filter: 'Services',
    shortDesc: 'Boutique stay and luxury resort presentation highlighting suites, amenities, and local experiences.',
    fullDesc: 'Perfect for boutique hotels, guest houses, and scenic travel resorts in Pakistan and worldwide. Showcases room tiers, amenity lists, guest reviews, and direct reservation inquiries.',
    image: '/src/assets/images/hero_workspace_laptop_1792820173219.jpg',
    badge: 'Hospitality & Travel',
    pages: ['Suites & Villas', 'Dining & Spa', 'Experiences', 'Reservation Inquiry'],
    keyFeatures: ['Suite Comparison', 'Amenity Checklist', 'Direct WhatsApp Booking']
  },
  {
    id: 'salon',
    title: 'Beauty Salon Website',
    filter: 'Services',
    shortDesc: 'Refined beauty salon and spa layout highlighting service menus, stylist profiles, and appointments.',
    fullDesc: 'Crafted for high-end beauty parlors, hair studios, and wellness spas. Includes treatment price lists, lookbook gallery, stylist bio cards, and quick WhatsApp appointment booking.',
    image: '/src/assets/images/demo_ecommerce_store_1792820174086.jpg',
    badge: 'Aesthetic & Wellness',
    pages: ['Treatments Menu', 'Stylist Team', 'Client Gallery', 'Book Appointment'],
    keyFeatures: ['Categorized Treatment Rates', 'Stylist Schedule', 'Instant Booking Link']
  },
  {
    id: 'corporate',
    title: 'Corporate Business Website',
    filter: 'Business',
    shortDesc: 'Authoritative corporate presentation presenting company vision, services, and executive leadership.',
    fullDesc: 'Engineered for financial advisory, legal practices, consulting firms, and commercial corporations. Emphasizes trust, institutional credentials, corporate governance, and proposal requests.',
    image: '/src/assets/images/demo_corporate_business_1792820174555.jpg',
    badge: 'Enterprise Corporate',
    pages: ['Corporate Vision', 'Advisory Capabilities', 'Leadership', 'Request Proposal'],
    keyFeatures: ['Executive Team Grid', 'Case Study Breakdowns', 'Professional Inquiry Form']
  },
  {
    id: 'portfolio',
    title: 'Personal Portfolio Website',
    filter: 'Personal',
    shortDesc: 'Distinctive personal brand website for independent designers, software creators, and consultants.',
    fullDesc: 'Built to elevate independent professionals and freelancers. Features clean timeline of achievements, selected works gallery, skill breakdown, and direct contact avenues.',
    image: '/src/assets/images/hero_workspace_laptop_1792820173219.jpg',
    badge: 'Personal Brand',
    pages: ['About & Bio', 'Featured Works', 'Capabilities & Stack', 'Get in Touch'],
    keyFeatures: ['Interactive Project Cards', 'Downloadable Resume / Bio', 'Direct WhatsApp Chat']
  },
  {
    id: 'fitness',
    title: 'Fitness and Gym Website',
    filter: 'Services',
    shortDesc: 'High-energy fitness studio and personal training platform highlighting membership tiers and coaches.',
    fullDesc: 'Tailored for gym clubs, crossfit boxes, and personal trainers. Features training schedule tables, trainer bios, member success transformations, and trial session requests.',
    image: '/src/assets/images/demo_corporate_business_1792820174555.jpg',
    badge: 'Health & Performance',
    pages: ['Programs & Classes', 'Trainers', 'Membership Tiers', 'Free Trial Request'],
    keyFeatures: ['Weekly Class Schedule', 'Trainer Profiles', 'Membership WhatsApp Link']
  },
  {
    id: 'construction',
    title: 'Construction Website',
    filter: 'Business',
    shortDesc: 'Sturdy, professional construction and contracting showcase displaying completed builds and machinery.',
    fullDesc: 'Designed for civil contractors, builders, and architectural engineering firms. Features past project blueprints, safety compliance records, equipment lists, and tender bid requests.',
    image: '/src/assets/images/demo_corporate_business_1792820174555.jpg',
    badge: 'Engineering & Build',
    pages: ['Commercial Builds', 'Residential Contracting', 'Safety & Standards', 'Request Quote'],
    keyFeatures: ['Blueprint Showcase', 'Machinery & Fleet', 'WhatsApp Tender Inquiry']
  },
  {
    id: 'education',
    title: 'Education Website',
    filter: 'Services',
    shortDesc: 'Modern academy and educational institution layout with curriculum details, faculty, and admissions.',
    fullDesc: 'Ideal for tutoring academies, private schools, language institutes, and online bootcamps. Features course listings, instructor credentials, admissions steps, and prospectus inquiries.',
    image: '/src/assets/images/hero_workspace_laptop_1792820173219.jpg',
    badge: 'Academic & Training',
    pages: ['Programs & Syllabus', 'Faculty', 'Admissions Criteria', 'Inquire / Prospectus'],
    keyFeatures: ['Course Curriculum Accordion', 'Fee Schedule', 'Admissions WhatsApp Chat']
  },
  {
    id: 'medical',
    title: 'Medical Clinic Website',
    filter: 'Services',
    shortDesc: 'Trustworthy medical practice and dental clinic layout with specialist doctor profiles and timings.',
    fullDesc: 'Designed for private healthcare clinics, dentists, and specialized diagnostic practices. Features clinical services, doctor credentials, operating hours, emergency notices, and WhatsApp consultation booking.',
    image: '/src/assets/images/demo_corporate_business_1792820174555.jpg',
    badge: 'Healthcare & Clinic',
    pages: ['Medical Services', 'Doctor Specialists', 'Clinic Hours', 'Book Appointment'],
    keyFeatures: ['Doctor Availability Table', 'Clinic Location Map Info', 'WhatsApp Consultation']
  }
];

export const FEATURED_CONCEPTS = [
  {
    id: 'featured-business',
    title: 'Modern Business Website',
    tagline: 'Modern Elegance & Corporate Distinction',
    category: 'Corporate Business Website',
    description: 'A clean and professional concept for a modern business with refined dark aesthetic, strategic spacing, and executive credibility.',
    image: '/src/assets/images/demo_corporate_business_1792820174555.jpg',
  },
  {
    id: 'featured-restaurant',
    title: 'Luxury Restaurant Website',
    tagline: 'Atmospheric Culinary Presentation',
    category: 'Restaurant Website',
    description: 'A premium restaurant concept with elegant photography, ambient warm gold lighting, and intuitive digital menu presentation.',
    image: '/src/assets/images/demo_restaurant_luxury_1792820173991.jpg',
  },
  {
    id: 'featured-interior',
    title: 'Interior Design Website',
    tagline: 'Timeless Luxury Spaces',
    category: 'Interior Design Website',
    description: 'A sophisticated concept for interior designers and luxury spaces, mirroring the exact high-end aesthetic of premier architectural studios.',
    image: '/public/assets/aistudio/e85055f2866590bbd42562d44898c5c0_3d21485a.jpg',
  }
];

export const PRICING_PACKAGES: PricingPackage[] = [
  {
    id: 'normal',
    name: 'NORMAL',
    price: 3000,
    formattedPrice: 'PKR 3,000',
    description: 'A simple, clean, and professional website design for startups and small businesses.',
    features: [
      'Professional visual layout tailored to your brand',
      'Fully responsive mobile and desktop design',
      'Standard business sections (Hero, About, Services, Contact)',
      'Contact information & social links section',
      'Clean HTML5, CSS3, and JavaScript code delivery',
      'WhatsApp contact integration configured',
      'Fast 48-hour delivery timeline',
      'Static website ready for free or low-cost hosting'
    ]
  },
  {
    id: 'premium',
    name: 'PREMIUM',
    price: 4500,
    formattedPrice: 'PKR 4,500',
    description: 'An enhanced design package for businesses that want a more refined and polished online presence.',
    features: [
      'More detailed visual styling & luxury dark/gold aesthetic',
      'Enhanced section layouts & dynamic grid presentations',
      'Premium image presentation & showcase cards',
      'Refined navigation with smooth scrolling interactions',
      'Interactive elements (filters, modal image previews)',
      'Contact or WhatsApp integration when requested and configured',
      'SEO-friendly meta tags & clean semantical markup',
      'Deliverable: Complete static code package + documentation'
    ]
  },
  {
    id: 'business',
    name: 'BUSINESS',
    price: 6000,
    formattedPrice: 'PKR 6,000',
    popular: true,
    description: 'A more comprehensive website design package for businesses requiring a richer presentation.',
    features: [
      'More extensive multi-section page architecture',
      'Advanced visual presentation within a static-site scope',
      'More detailed gallery or portfolio layouts with category filters',
      'Responsive navigation & sleek mobile menu',
      'Interactive frontend elements (custom forms, lightboxes)',
      'Contact or WhatsApp integration with pre-filled messaging',
      'Priority turnaround & dedicated designer revisions',
      'Comprehensive static asset suite ready for instant deployment'
    ]
  }
];
