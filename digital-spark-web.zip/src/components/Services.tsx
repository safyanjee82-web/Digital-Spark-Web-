import React from 'react';
import { GoldDivider } from './GoldDivider';
import { SERVICES } from '../data/mockData';
import { Briefcase, ShoppingBag, Utensils, Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';

interface ServicesProps {
  onExploreService: (filter: string) => void;
  onOrderService: (category: string) => void;
}

export const Services: React.FC<ServicesProps> = ({ onExploreService, onOrderService }) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Briefcase':
        return <Briefcase className="w-6 h-6 text-[#D9AD62]" />;
      case 'ShoppingBag':
        return <ShoppingBag className="w-6 h-6 text-[#D9AD62]" />;
      case 'Utensils':
        return <Utensils className="w-6 h-6 text-[#D9AD62]" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-[#D9AD62]" />;
      default:
        return <Sparkles className="w-6 h-6 text-[#D9AD62]" />;
    }
  };

  return (
    <section id="services" className="py-20 md:py-28 bg-[#0b0b0b] relative">
      {/* Decorative background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-64 bg-[#D9AD62]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Our Services
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Creative website design solutions tailored to your business, with pure static precision and responsive elegance.
          </p>
        </div>

        {/* 4 Service Cards Grid matching reference image */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service) => (
            <div
              key={service.id}
              className="group relative bg-[#151515] hover:bg-[#181818] rounded-xl p-6 border border-[#D9AD62]/20 hover:border-[#D9AD62]/60 transition-all duration-300 shadow-[0_8px_25px_-5px_rgba(0,0,0,0.6)] flex flex-col justify-between"
            >
              {/* Top ambient highlight */}
              <div className="absolute -top-px left-1/4 right-1/4 h-[1px] bg-gradient-to-r from-transparent via-[#D9AD62]/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

              <div>
                {/* Icon box with gold hairline border */}
                <div className="w-13 h-13 rounded-lg bg-[#0e0e0e] border border-[#D9AD62]/35 flex items-center justify-center mb-5 group-hover:border-[#D9AD62] group-hover:shadow-[0_0_15px_rgba(217,173,98,0.3)] transition-all">
                  {getIcon(service.icon)}
                </div>

                {/* Title */}
                <h3 className="font-serif-luxury text-xl sm:text-2xl font-normal text-white mb-2.5 group-hover:text-[#F4D79B] transition-colors">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-xs sm:text-sm text-[#A0A0A0] leading-relaxed mb-6 font-light">
                  {service.description}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-4 border-t border-[#D9AD62]/15">
                <button
                  onClick={() => onExploreService(service.filterTag)}
                  className="w-full py-2 px-3 rounded text-xs font-medium text-[#F4D79B] hover:text-white bg-[#1f1f1f] hover:bg-[#252525] border border-[#D9AD62]/20 hover:border-[#D9AD62]/40 transition-all flex items-center justify-between cursor-pointer"
                >
                  <span>Explore Design</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onOrderService(service.category)}
                  className="w-full py-2 px-3 rounded text-xs font-semibold text-[#080808] gold-gradient-btn flex items-center justify-between cursor-pointer"
                >
                  <span>Order This Design</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#080808]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
