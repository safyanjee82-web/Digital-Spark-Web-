import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface ClosingCTAProps {
  onStartClick: () => void;
}

export const ClosingCTA: React.FC<ClosingCTAProps> = ({ onStartClick }) => {
  return (
    <section className="py-24 bg-[#080808] relative overflow-hidden text-center border-t border-[#D9AD62]/20">
      {/* Ambient background gold glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[300px] bg-[#D9AD62]/10 blur-[130px] pointer-events-none rounded-full" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 space-y-7">
        <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
          Ready to Elevate Your Online Brand?
        </h2>

        <p className="text-sm sm:text-base text-[#BDBDBD] max-w-xl mx-auto font-light leading-relaxed">
          Get a bespoke, luxury-styled static website tailored to your business, with swift delivery and transparent Pakistani pricing.
        </p>

        {/* Prominent Gold Closing Button matching reference image */}
        <div className="pt-2">
          <button
            onClick={onStartClick}
            className="gold-gradient-btn px-10 py-4 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-widest inline-flex items-center gap-3 cursor-pointer shadow-[0_10px_35px_rgba(217,173,98,0.4)] hover:scale-105 transition-transform"
          >
            <span>Start Your Journey</span>
            <ArrowUpRight className="w-4 h-4 text-[#080808]" />
          </button>
        </div>

        {/* Elegant Script Tagline matching reference image */}
        <div className="pt-6">
          <p className="font-script text-3xl sm:text-5xl text-[#F4D79B] tracking-wide select-none drop-shadow-[0_2px_12px_rgba(217,173,98,0.4)]">
            Let's Create Something Extraordinary
          </p>
        </div>
      </div>
    </section>
  );
};
