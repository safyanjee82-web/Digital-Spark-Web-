import React, { useEffect, useState } from 'react';
import { CategoryItem } from '../data/mockData';
import { X, Check, Monitor, Smartphone, MessageSquare, ExternalLink } from 'lucide-react';

interface PreviewModalProps {
  item: CategoryItem | null;
  onClose: () => void;
  onOrderThis: (category: string) => void;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ item, onClose, onOrderThis }) => {
  const [viewMode, setViewMode] = useState<'desktop' | 'mobile'>('desktop');

  // Handle ESC key to close modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (item) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'unset';
    };
  }, [item, onClose]);

  if (!item) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      {/* Click outside backdrop */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto bg-[#141414] border border-[#D9AD62]/40 rounded-2xl shadow-[0_25px_60px_-15px_rgba(217,173,98,0.3)] z-10 text-white flex flex-col">
        {/* Modal Header */}
        <div className="sticky top-0 z-20 flex items-center justify-between px-6 py-4 bg-[#141414]/95 backdrop-blur-md border-b border-[#D9AD62]/20">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-[#D9AD62]" />
            <span className="text-xs font-semibold uppercase tracking-widest text-[#F4D79B]">
              {item.badge}
            </span>
          </div>

          <div className="flex items-center gap-3">
            {/* Viewport simulation toggle */}
            <div className="hidden sm:flex items-center p-1 bg-[#0a0a0a] rounded-lg border border-[#D9AD62]/20 text-xs">
              <button
                onClick={() => setViewMode('desktop')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  viewMode === 'desktop'
                    ? 'bg-[#D9AD62] text-[#080808] font-semibold'
                    : 'text-[#BDBDBD] hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Desktop</span>
              </button>
              <button
                onClick={() => setViewMode('mobile')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  viewMode === 'mobile'
                    ? 'bg-[#D9AD62] text-[#080808] font-semibold'
                    : 'text-[#BDBDBD] hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-[#BDBDBD] hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Close preview modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Main Visual Display */}
          <div className="flex justify-center bg-[#0a0a0a] rounded-xl p-3 border border-[#D9AD62]/20 overflow-hidden">
            <div
              className={`transition-all duration-300 overflow-hidden rounded-lg border border-[#D9AD62]/30 relative shadow-2xl ${
                viewMode === 'desktop' ? 'w-full aspect-[16/10]' : 'w-[320px] aspect-[9/16]'
              }`}
            >
              {/* Fake browser bar */}
              <div className="h-7 bg-[#1c1c1c] border-b border-white/10 flex items-center px-3 gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-yellow-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500/80" />
                </div>
                <div className="flex-1 mx-4 bg-[#0a0a0a] rounded text-[10px] text-[#A0A0A0] text-center py-0.5 truncate border border-white/5 font-mono">
                  https://digitalsparkweb.com/demos/{item.id}
                </div>
              </div>

              {/* Image preview */}
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover object-top"
              />
            </div>
          </div>

          {/* Details & Specifications */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="md:col-span-2 space-y-4">
              <h3 className="font-serif-luxury text-3xl font-light text-white">
                {item.title}
              </h3>
              <p className="text-sm text-[#CCCCCC] leading-relaxed font-light">
                {item.fullDesc}
              </p>

              {/* Layout sections included */}
              <div>
                <p className="text-xs uppercase font-semibold text-[#D9AD62] tracking-wider mb-2">
                  Key Layout Sections Included:
                </p>
                <div className="flex flex-wrap gap-2">
                  {item.pages.map((p, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded bg-[#1f1f1f] border border-[#D9AD62]/25 text-xs text-[#E0E0E0] font-light"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>

              {/* Technical disclaimer */}
              <div className="p-3.5 rounded-lg bg-[#111111] border border-[#D9AD62]/20 text-xs text-[#999999] leading-relaxed">
                <span className="text-[#F4D79B] font-semibold">Important Scope Notice:</span> This demonstration represents a visual design layout. DIGITAL SPARK WEB provides high-speed static frontend code (HTML5, CSS3, JavaScript). Advanced features like databases, logins, or payment processing can be quoted separately upon consultation.
              </div>
            </div>

            {/* Right Column: Key Features & CTA */}
            <div className="bg-[#181818] p-5 rounded-xl border border-[#D9AD62]/30 flex flex-col justify-between">
              <div>
                <p className="text-xs uppercase font-bold text-[#F4D79B] tracking-wider mb-3">
                  Highlights
                </p>
                <ul className="space-y-2.5 text-xs text-[#CCCCCC] mb-6">
                  {item.keyFeatures.map((kf, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#D9AD62] shrink-0 mt-0.5" />
                      <span>{kf}</span>
                    </li>
                  ))}
                  <li className="flex items-start gap-2">
                    <Check className="w-4 h-4 text-[#D9AD62] shrink-0 mt-0.5" />
                    <span>WhatsApp Direct Ordering Ready</span>
                  </li>
                </ul>
              </div>

              <div className="space-y-2.5">
                <button
                  onClick={() => {
                    onOrderThis(item.title);
                    onClose();
                  }}
                  className="w-full gold-gradient-btn py-3 rounded text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageSquare className="w-4 h-4 text-[#080808]" />
                  <span>Order This Design</span>
                </button>

                <p className="text-[10px] text-center text-[#7E7E7E]">
                  Pre-fills this category into your WhatsApp order form
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
