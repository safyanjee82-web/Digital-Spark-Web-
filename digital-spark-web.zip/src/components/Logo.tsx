import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 'md', showText = true }) => {
  const iconSizes = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-lg',
    lg: 'text-2xl',
  };

  const subtitleSizes = {
    sm: 'text-[9px] tracking-[0.25em]',
    md: 'text-[10px] tracking-[0.3em]',
    lg: 'text-xs tracking-[0.35em]',
  };

  return (
    <div className={`inline-flex items-center gap-3.5 select-none ${className}`}>
      {/* Geometric Gold Symbol */}
      <div className={`relative ${iconSizes[size]} shrink-0 flex items-center justify-center`}>
        <svg
          viewBox="0 0 44 44"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-[0_2px_8px_rgba(217,173,98,0.4)]"
        >
          <defs>
            <linearGradient id="goldGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFF6E5" />
              <stop offset="45%" stopColor="#D9AD62" />
              <stop offset="100%" stopColor="#9E742A" />
            </linearGradient>
            <linearGradient id="goldGrad2" x1="100%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#F4D79B" />
              <stop offset="50%" stopColor="#D9AD62" />
              <stop offset="100%" stopColor="#785517" />
            </linearGradient>
            <linearGradient id="goldGradStroke" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="50%" stopColor="#F4D79B" />
              <stop offset="100%" stopColor="#B38531" />
            </linearGradient>
          </defs>

          {/* Outer faceted geometric shield / diamond spark */}
          <polygon
            points="22,3 41,13 41,31 22,41 3,31 3,13"
            stroke="url(#goldGradStroke)"
            strokeWidth="1.8"
            fill="#121212"
            fillOpacity="0.8"
          />

          {/* Inner faceted geometric spark facets */}
          <path
            d="M22,3 L41,13 L22,22 Z"
            fill="url(#goldGrad1)"
            opacity="0.85"
          />
          <path
            d="M3,13 L22,3 L22,22 Z"
            fill="url(#goldGrad2)"
            opacity="0.6"
          />
          <path
            d="M3,13 L22,22 L22,41 L3,31 Z"
            fill="url(#goldGrad1)"
            opacity="0.45"
          />
          <path
            d="M41,13 L41,31 L22,41 L22,22 Z"
            fill="url(#goldGrad2)"
            opacity="0.95"
          />

          {/* Center core spark highlight */}
          <circle cx="22" cy="22" r="2.5" fill="#FFFBF2" />
        </svg>
      </div>

      {/* Refined Brand Wordmark */}
      {showText && (
        <div className="flex flex-col">
          <span
            className={`font-serif-luxury font-bold leading-none tracking-[0.08em] text-white ${textSizes[size]}`}
          >
            DIGITAL SPARK
          </span>
          <span
            className={`font-sans font-semibold uppercase text-[#D9AD62] leading-tight ${subtitleSizes[size]}`}
          >
            WEB AGENCY
          </span>
        </div>
      )}
    </div>
  );
};
