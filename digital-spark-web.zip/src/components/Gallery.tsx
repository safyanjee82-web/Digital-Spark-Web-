import React, { useState } from 'react';
import { GoldDivider } from './GoldDivider';
import { GALLERY_ITEMS, CategoryItem } from '../data/mockData';
import { Eye, ArrowRight, CheckCircle2 } from 'lucide-react';

interface GalleryProps {
  onPreview: (item: CategoryItem) => void;
  onOrderDesign: (category: string) => void;
  activeFilter?: string;
}

const FILTERS = [
  'All Designs',
  'Business',
  'Shopping',
  'Food',
  'Property',
  'Interior Design',
  'Personal',
  'Services',
] as const;

export const Gallery: React.FC<GalleryProps> = ({ onPreview, onOrderDesign, activeFilter: propFilter }) => {
  const [selectedFilter, setSelectedFilter] = useState<string>(propFilter || 'All Designs');

  // React to propFilter if changed by parent
  React.useEffect(() => {
    if (propFilter) {
      setSelectedFilter(propFilter);
    }
  }, [propFilter]);

  const filteredItems = selectedFilter === 'All Designs'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((item) => item.filter === selectedFilter);

  return (
    <section id="gallery" className="py-20 md:py-28 bg-[#0a0a0a] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Explore Our Website Designs
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Discover beautiful website concepts for different industries. Choose your sector or browse all twelve curated demonstration templates.
          </p>
        </div>

        {/* Filter Segmented Control adhering to frontend-design interactive button discipline */}
        <div className="flex flex-wrap items-center justify-center gap-2 p-1.5 bg-[#121212] border border-[#D9AD62]/20 rounded-xl max-w-4xl mx-auto mb-14 shadow-lg">
          {FILTERS.map((filter) => {
            const isActive = selectedFilter === filter;
            return (
              <button
                key={filter}
                onClick={() => setSelectedFilter(filter)}
                className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-all duration-200 cursor-pointer whitespace-nowrap ${
                  isActive
                    ? 'bg-[#D9AD62] text-[#080808] font-semibold shadow-[0_2px_10px_rgba(217,173,98,0.4)]'
                    : 'text-[#BDBDBD] hover:text-white hover:bg-white/5'
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>

        {/* Gallery Cards Grid (12 items) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group bg-[#141414] hover:bg-[#181818] rounded-xl overflow-hidden border border-[#D9AD62]/20 hover:border-[#D9AD62]/60 transition-all duration-300 shadow-[0_10px_30px_-8px_rgba(0,0,0,0.7)] flex flex-col justify-between"
            >
              <div>
                {/* Image Container with zoom */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-[#1f1f1f]">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#141414] via-transparent to-black/20" />
                  
                  {/* Category Pill Tag replaced with clean unboxed badge text */}
                  <div className="absolute top-3 left-3 bg-[#0a0a0a]/85 backdrop-blur-sm border border-[#D9AD62]/30 px-2.5 py-1 rounded text-[10px] font-semibold uppercase tracking-wider text-[#F4D79B]">
                    {item.filter}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="font-serif-luxury text-2xl font-normal text-white group-hover:text-[#F4D79B] transition-colors mb-2">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-[#A0A0A0] leading-relaxed line-clamp-2 font-light">
                    {item.shortDesc}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="p-6 pt-0 space-y-2">
                <button
                  onClick={() => onPreview(item)}
                  className="w-full py-2.5 px-4 rounded text-xs font-medium text-[#F4D79B] hover:text-white bg-[#1e1e1e] hover:bg-[#262626] border border-[#D9AD62]/25 hover:border-[#D9AD62]/50 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Preview</span>
                </button>

                <button
                  onClick={() => onOrderDesign(item.title)}
                  className="w-full py-2.5 px-4 rounded text-xs font-semibold text-[#080808] gold-gradient-btn flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#080808]" />
                  <span>Order This Design</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Gallery bottom note */}
        <div className="mt-12 text-center text-xs text-[#7A7A7A] max-w-xl mx-auto">
          <p>
            *All gallery designs are demonstrated as responsive static web layouts. Need additional pages, custom palettes, or specific sections? Let us know when ordering.
          </p>
        </div>
      </div>
    </section>
  );
};
