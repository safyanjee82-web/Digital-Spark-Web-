import React from 'react';
import { Logo } from './Logo';
import { Mail, Phone, MessageSquare, Youtube, ChevronUp, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="contact" className="bg-[#050505] text-[#888888] border-t border-[#D9AD62]/20 pt-16 pb-12 relative overflow-hidden">
      {/* Subtle ambient lighting */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-24 bg-[#D9AD62]/5 blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Main Grid: Brand, Navigation, and Direct Contact */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-12 mb-12">
          {/* Col 1: Brand & Overview (5 cols on md+) */}
          <div className="md:col-span-5 space-y-4">
            <Logo size="md" />
            <p className="text-xs sm:text-sm text-[#A0A0A0] leading-relaxed max-w-md font-light pt-1">
              DIGITAL SPARK WEB is a premier website design agency delivering high-speed, aesthetically refined static websites with luxury black-and-gold styling, bespoke layouts, and direct WhatsApp consultations.
            </p>
            <p className="text-xs text-[#7A7A7A] font-light">
              Available for new projects, custom redesigns, and frontend consultancy.
            </p>
          </div>

          {/* Col 2: Quick Navigation (3 cols on md+) */}
          <div className="md:col-span-3 space-y-3">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#F4D79B]">
              Navigation
            </p>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#home" className="hover:text-white transition-colors">
                  Home Overview
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-white transition-colors">
                  Design Services
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-white transition-colors">
                  12 Demo Concepts
                </a>
              </li>
              <li>
                <a href="#featured" className="hover:text-white transition-colors">
                  Featured Projects
                </a>
              </li>
              <li>
                <a href="#pricing" className="hover:text-white transition-colors">
                  Design Packages (PKR)
                </a>
              </li>
              <li>
                <a href="#publishing" className="hover:text-white transition-colors">
                  Live Publishing
                </a>
              </li>
            </ul>
          </div>

          {/* Col 3: Direct Contact Details (4 cols on md+) */}
          <div className="md:col-span-4 space-y-4">
            <p className="text-xs font-semibold uppercase tracking-widest text-[#F4D79B]">
              Contact Details
            </p>

            <div className="space-y-3 text-xs">
              {/* Email (mailto link) */}
              <a
                href="mailto:safyanjee82@gmail.com"
                className="group flex items-center gap-3 p-3 rounded-lg bg-[#111111] border border-[#D9AD62]/20 hover:border-[#D9AD62] hover:bg-[#161616] transition-all"
              >
                <div className="w-8 h-8 rounded bg-[#1a1a1a] border border-[#D9AD62]/30 flex items-center justify-center shrink-0 group-hover:border-[#D9AD62] transition-colors">
                  <Mail className="w-4 h-4 text-[#D9AD62]" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] uppercase font-semibold text-[#888888]">Email Us</p>
                  <p className="text-xs text-white group-hover:text-[#F4D79B] transition-colors truncate font-medium">
                    safyanjee82@gmail.com
                  </p>
                </div>
              </a>

              {/* Mobile / Phone (tel link) */}
              <a
                href="tel:+923045768929"
                className="group flex items-center gap-3 p-3 rounded-lg bg-[#111111] border border-[#D9AD62]/20 hover:border-[#D9AD62] hover:bg-[#161616] transition-all"
              >
                <div className="w-8 h-8 rounded bg-[#1a1a1a] border border-[#D9AD62]/30 flex items-center justify-center shrink-0 group-hover:border-[#D9AD62] transition-colors">
                  <Phone className="w-4 h-4 text-[#D9AD62]" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] uppercase font-semibold text-[#888888]">Mobile / WhatsApp Call</p>
                  <p className="text-xs text-white group-hover:text-[#F4D79B] transition-colors font-medium tabular-nums whitespace-nowrap font-mono">
                    +92 304 5768929
                  </p>
                </div>
              </a>

              {/* WhatsApp Chat Button */}
              <a
                href="https://wa.me/message/OXDWP7NO5U7RI1"
                target="_blank"
                rel="noopener noreferrer"
                className="gold-gradient-btn flex items-center justify-between gap-3 p-3 rounded-lg text-xs font-semibold uppercase tracking-wider shadow-md hover:scale-[1.01] transition-transform"
              >
                <div className="flex items-center gap-2.5">
                  <MessageSquare className="w-4 h-4 text-[#080808]" />
                  <span>Chat on WhatsApp</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-[#080808]" />
              </a>

              {/* YouTube Channel link */}
              <a
                href="https://youtube.com/@digitalsparkwebwebsitedesign?si=nE8evWIFdmGnA4k2"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-3 p-3 rounded-lg bg-[#111111] border border-[#D9AD62]/20 hover:border-[#D9AD62] hover:bg-[#161616] transition-all"
              >
                <div className="w-8 h-8 rounded bg-[#1a1a1a] border border-[#D9AD62]/30 flex items-center justify-center shrink-0 group-hover:border-[#D9AD62] transition-colors">
                  <Youtube className="w-4 h-4 text-red-500" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] uppercase font-semibold text-[#888888]">YouTube Channel</p>
                  <p className="text-xs text-white group-hover:text-[#F4D79B] transition-colors truncate font-medium">
                    Digital Spark Web Website Design
                  </p>
                </div>
                <ExternalLink className="w-3.5 h-3.5 text-[#777777] group-hover:text-white shrink-0" />
              </a>
            </div>
          </div>
        </div>

        {/* Disclaimer row */}
        <div className="border-t border-white/5 py-6 text-[11px] text-[#666666] leading-relaxed">
          <p>
            <span className="text-[#999999] font-medium">Service Scope Clarification:</span> All websites delivered by DIGITAL SPARK WEB are high-speed, modern static frontend designs built with clean HTML5, CSS3, and JavaScript. Complex backends, user databases, and payment gateways can be quoted separately. Live hosting and domain configurations are supported via optional publishing consultations.
          </p>
        </div>

        {/* Bottom row */}
        <div className="border-t border-[#D9AD62]/15 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#7A7A7A]">
          <p>© {new Date().getFullYear()} DIGITAL SPARK WEB. All rights reserved.</p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-xs text-[#D9AD62] hover:text-white transition-colors cursor-pointer"
          >
            <span>Back to top</span>
            <ChevronUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
};
