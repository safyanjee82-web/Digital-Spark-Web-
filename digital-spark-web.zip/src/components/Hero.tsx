import React from 'react';
import { ArrowRight, Play, Sparkles } from 'lucide-react';

interface HeroProps {
  onExploreClick: () => void;
  onRequestQuoteClick: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onExploreClick, onRequestQuoteClick }) => {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Ambient background gold lighting glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-[#D9AD62]/10 blur-[140px] pointer-events-none rounded-full" />
      <div className="absolute top-12 right-10 w-96 h-96 bg-[#D9AD62]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
        {/* Subtle kicker */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#D9AD62]/30 bg-[#141414]/80 text-[#F4D79B] text-xs font-medium tracking-wide mb-6">
          <Sparkles className="w-3.5 h-3.5 text-[#D9AD62]" />
          <span>Curated Website Design & Frontend Studio</span>
        </div>

        {/* Main Headline */}
        <h1 className="font-serif-luxury text-4xl sm:text-6xl md:text-7xl lg:text-7xl font-light text-white tracking-tight leading-[1.08] text-balance max-w-4xl mx-auto">
          Transform Your Business Online
          <span className="block italic font-normal gold-gradient-text mt-1 sm:mt-2">
            Into a Powerful First Impression
          </span>
        </h1>

        {/* Gold curved flourish divider line */}
        <div className="flex items-center justify-center my-6">
          <svg className="w-72 h-4 text-[#D9AD62]" viewBox="0 0 280 16" fill="none">
            <path
              d="M0,8 C70,16 100,0 140,8 C180,16 210,0 280,8"
              stroke="url(#goldLineGrad)"
              strokeWidth="1.5"
            />
            <defs>
              <linearGradient id="goldLineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#D9AD62" stopOpacity="0" />
                <stop offset="25%" stopColor="#D9AD62" stopOpacity="0.5" />
                <stop offset="50%" stopColor="#F4D79B" stopOpacity="1" />
                <stop offset="75%" stopColor="#D9AD62" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#D9AD62" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* Tagline Pills text */}
        <div className="flex items-center justify-center gap-3 text-xs sm:text-sm font-medium text-[#F4D79B] tracking-wider uppercase mb-5">
          <span>Modern Design</span>
          <span className="text-[#D9AD62]">•</span>
          <span>Premium Quality</span>
          <span className="text-[#D9AD62]">•</span>
          <span>Tailored for You</span>
        </div>

        {/* Supporting description */}
        <p className="text-sm sm:text-base md:text-lg text-[#BDBDBD] max-w-2xl mx-auto leading-relaxed mb-10 font-light">
          Professional website designs for businesses, startups, and entrepreneurs who want to stand out online with luxury aesthetics, high speed, and verified WhatsApp ordering.
        </p>

        {/* CTA Buttons matching reference image */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-5 mb-16">
          <button
            onClick={onExploreClick}
            className="gold-gradient-btn px-8 py-3.5 rounded text-xs sm:text-sm font-semibold uppercase tracking-wider flex items-center gap-2.5 cursor-pointer w-full sm:w-auto justify-center"
          >
            <span>Explore Our Designs</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            onClick={onRequestQuoteClick}
            className="px-8 py-3.5 rounded text-xs sm:text-sm font-medium text-white border border-[#D9AD62]/40 hover:border-[#D9AD62] hover:bg-[#D9AD62]/10 transition-all flex items-center gap-2.5 cursor-pointer w-full sm:w-auto justify-center"
          >
            <div className="w-6 h-6 rounded-full border border-[#D9AD62]/60 flex items-center justify-center bg-[#191919]">
              <Play className="w-3 h-3 text-[#F4D79B] fill-[#F4D79B] ml-0.5" />
            </div>
            <span>Request a Quote</span>
          </button>
        </div>

        {/* Cinematic Hero Image Showcase */}
        <div className="relative mx-auto max-w-5xl rounded-2xl p-1.5 sm:p-2 bg-gradient-to-b from-[#D9AD62]/40 via-[#D9AD62]/15 to-transparent shadow-[0_20px_70px_-15px_rgba(217,173,98,0.25)]">
          <div className="relative rounded-xl overflow-hidden bg-[#111111] aspect-[16/9] border border-[#D9AD62]/30 group">
            <img
              src="/src/assets/images/hero_workspace_laptop_1792820173219.jpg"
              alt="Digital Spark Web Luxury Workspace and Modern Website Showcase"
              className="w-full h-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-700"
              loading="eager"
            />
            {/* Ambient vignette and reflection */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#080808] via-transparent to-[#080808]/20 pointer-events-none" />

            {/* Bottom Floating Badge */}
            <div className="absolute bottom-4 left-4 right-4 sm:left-6 sm:right-auto flex items-center gap-3 bg-[#0c0c0c]/90 backdrop-blur-md border border-[#D9AD62]/35 px-4 py-2.5 rounded-lg text-left">
              <div className="w-2 h-2 rounded-full bg-[#D9AD62] animate-pulse" />
              <div>
                <p className="text-[11px] font-semibold text-white tracking-wide">
                  DIGITAL SPARK WEB STUDIO
                </p>
                <p className="text-[10px] text-[#D9AD62]">
                  Static & Frontend Excellence · Handcrafted for Pakistan & Global Brands
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
