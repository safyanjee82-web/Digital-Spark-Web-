import React, { useState } from 'react';
import JSZip from 'jszip';
import { X, Download, FileCode, Check, Copy } from 'lucide-react';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [downloading, setDownloading] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'html' | 'css' | 'js'>('info');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    try {
      setDownloading(true);
      const zip = new JSZip();
      const folder = zip.folder('digital-spark-web');

      // Fetch or assemble the standalone files
      const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DIGITAL SPARK WEB — Premium Website Design Agency</title>
  <meta name="description" content="Luxury website design agency offering curated design packages, interactive gallery, and WhatsApp ordering.">
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Alex+Brush&family=Cormorant+Garamond:wght@400;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
</head>
<body>
  <!-- HEADER -->
  <header class="header">
    <div class="container nav-container">
      <a href="#home" class="logo">
        <svg class="logo-icon" viewBox="0 0 44 44" fill="none">
          <polygon points="22,3 41,13 41,31 22,41 3,31 3,13" stroke="#D9AD62" stroke-width="2" fill="#121212"/>
          <path d="M22,3 L41,13 L22,22 Z" fill="#D9AD62"/>
          <path d="M41,13 L41,31 L22,41 L22,22 Z" fill="#B38531"/>
          <circle cx="22" cy="22" r="2.5" fill="#FFF"/>
        </svg>
        <div class="logo-text">
          <span class="brand-title">DIGITAL SPARK</span>
          <span class="brand-sub">WEB AGENCY</span>
        </div>
      </a>
      <nav class="nav-links">
        <a href="#home">Home</a>
        <a href="#services">Services</a>
        <a href="#gallery">Demo Gallery</a>
        <a href="#pricing">Pricing</a>
        <a href="#order">Order</a>
      </nav>
      <a href="#order" class="btn btn-gold">Order a Website</a>
    </div>
  </header>

  <!-- HERO -->
  <section id="home" class="hero">
    <div class="container hero-content">
      <span class="kicker">Curated Website Design & Frontend Studio</span>
      <h1>Transform Your Business Online<br><span class="gold-text italic">Into a Powerful First Impression</span></h1>
      <div class="gold-divider"><span class="diamond"></span></div>
      <p class="tagline">Modern Design &bull; Premium Quality &bull; Tailored for You</p>
      <p class="desc">Professional website designs for businesses, startups, and entrepreneurs who want to stand out online with luxury aesthetics, high speed, and verified WhatsApp ordering.</p>
      <div class="hero-actions">
        <a href="#gallery" class="btn btn-gold">Explore Our Designs &rarr;</a>
        <a href="#order" class="btn btn-outline">Request a Quote</a>
      </div>
    </div>
  </section>

  <!-- SERVICES -->
  <section id="services" class="section services-section">
    <div class="container">
      <div class="section-title">
        <h2>Our Services</h2>
        <div class="gold-divider"><span class="diamond"></span></div>
        <p>Creative website design solutions tailored to your business.</p>
      </div>
      <div class="grid grid-4">
        <div class="card service-card">
          <h3>Business Website Design</h3>
          <p>Professional website layouts for startups and growing businesses.</p>
          <button class="btn btn-sm btn-outline" onclick="filterGallery('Business')">Explore Design</button>
          <button class="btn btn-sm btn-gold" onclick="selectOrderCategory('Corporate Business')">Order This Design</button>
        </div>
        <div class="card service-card">
          <h3>Online Store Design</h3>
          <p>Attractive product presentation layouts for online shopping businesses.</p>
          <button class="btn btn-sm btn-outline" onclick="filterGallery('Shopping')">Explore Design</button>
          <button class="btn btn-sm btn-gold" onclick="selectOrderCategory('Online Shopping')">Order This Design</button>
        </div>
        <div class="card service-card">
          <h3>Restaurant Website Design</h3>
          <p>Beautiful restaurant layouts featuring menus, food imagery, and contact information.</p>
          <button class="btn btn-sm btn-outline" onclick="filterGallery('Food')">Explore Design</button>
          <button class="btn btn-sm btn-gold" onclick="selectOrderCategory('Restaurant')">Order This Design</button>
        </div>
        <div class="card service-card">
          <h3>Portfolio Website Design</h3>
          <p>Professional portfolios for freelancers, creators, and service providers.</p>
          <button class="btn btn-sm btn-outline" onclick="filterGallery('Personal')">Explore Design</button>
          <button class="btn btn-sm btn-gold" onclick="selectOrderCategory('Personal Portfolio')">Order This Design</button>
        </div>
      </div>
    </div>
  </section>

  <!-- PRICING -->
  <section id="pricing" class="section pricing-section">
    <div class="container">
      <div class="section-title">
        <h2>Choose Your Website Package</h2>
        <div class="gold-divider"><span class="diamond"></span></div>
        <p>Select the website design package that best fits your needs.</p>
      </div>
      <div class="grid grid-3">
        <div class="card pricing-card">
          <h3 class="gold-text">NORMAL</h3>
          <div class="price">PKR 3,000</div>
          <p class="package-desc">A simple, clean, and professional website design for startups and small businesses.</p>
          <ul class="features">
            <li>Professional visual layout</li>
            <li>Responsive design</li>
            <li>Standard business sections</li>
            <li>Contact information section</li>
            <li>Basic HTML, CSS, and JavaScript</li>
            <li>WhatsApp contact integration</li>
          </ul>
          <button class="btn btn-outline" onclick="selectPackage('Normal', 'PKR 3,000')">Choose Normal</button>
        </div>
        <div class="card pricing-card">
          <h3 class="gold-text">PREMIUM</h3>
          <div class="price">PKR 4,500</div>
          <p class="package-desc">An enhanced design package for businesses that want a more refined and polished online presence.</p>
          <ul class="features">
            <li>More detailed visual styling</li>
            <li>Enhanced section layouts</li>
            <li>Premium image presentation</li>
            <li>Responsive mobile design</li>
            <li>Refined navigation and interactions</li>
            <li>Contact or WhatsApp integration</li>
          </ul>
          <button class="btn btn-outline" onclick="selectPackage('Premium', 'PKR 4,500')">Choose Premium</button>
        </div>
        <div class="card pricing-card featured-pkg">
          <div class="badge">Most Popular</div>
          <h3 class="gold-text">BUSINESS</h3>
          <div class="price">PKR 6,000</div>
          <p class="package-desc">A more comprehensive website design package for businesses requiring a richer presentation.</p>
          <ul class="features">
            <li>More extensive page sections</li>
            <li>Advanced visual presentation</li>
            <li>Detailed gallery or portfolio layouts</li>
            <li>Responsive navigation</li>
            <li>Interactive frontend elements</li>
            <li>Contact or WhatsApp integration</li>
          </ul>
          <button class="btn btn-gold" onclick="selectPackage('Business', 'PKR 6,000')">Choose Business</button>
        </div>
      </div>
    </div>
  </section>

  <!-- ORDER FORM -->
  <section id="order" class="section order-section">
    <div class="container">
      <div class="section-title">
        <h2>Start Your Website Project</h2>
        <div class="gold-divider"><span class="diamond"></span></div>
        <p>Submit your project details directly to our WhatsApp consultant.</p>
      </div>
      <form id="orderForm" class="card order-form" onsubmit="submitWhatsApp(event)">
        <div class="form-row">
          <div class="form-group">
            <label>1. Full Name *</label>
            <input type="text" id="fullName" required placeholder="Your full name">
          </div>
          <div class="form-group">
            <label>2. WhatsApp Number *</label>
            <input type="tel" id="whatsappNum" required placeholder="+92 300 1234567">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>3. Business Name *</label>
            <input type="text" id="businessName" required placeholder="Business / Brand Name">
          </div>
          <div class="form-group">
            <label>4. Business Category *</label>
            <select id="businessCategory">
              <option value="Restaurant">Restaurant</option>
              <option value="Online Shopping">Online Shopping</option>
              <option value="Real Estate">Real Estate</option>
              <option value="Interior Design">Interior Design</option>
              <option value="Hotel and Travel">Hotel and Travel</option>
              <option value="Beauty Salon">Beauty Salon</option>
              <option value="Corporate Business" selected>Corporate Business</option>
              <option value="Personal Portfolio">Personal Portfolio</option>
              <option value="Fitness and Gym">Fitness and Gym</option>
              <option value="Construction">Construction</option>
              <option value="Education">Education</option>
              <option value="Medical Clinic">Medical Clinic</option>
              <option value="Other">Other</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>5. Selected Package *</label>
            <select id="packageSelect" onchange="updatePrice()">
              <option value="Normal">Normal — PKR 3,000</option>
              <option value="Premium">Premium — PKR 4,500</option>
              <option value="Business" selected>Business — PKR 6,000</option>
            </select>
          </div>
          <div class="form-group">
            <label>6. Website Design Price</label>
            <input type="text" id="designPrice" readonly value="PKR 6,000">
          </div>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label>7. Publishing Requirement *</label>
            <select id="publishingOption" onchange="toggleDuration()">
              <option value="Website Design Only">Website Design Only</option>
              <option value="I Need Live Publishing">I Need Live Publishing</option>
              <option value="I Need Advice">I Need Advice</option>
            </select>
          </div>
          <div class="form-group" id="durationGroup" style="display:none;">
            <label>8. Preferred Publishing Duration</label>
            <select id="publishingDuration">
              <option value="One Month">One Month</option>
              <option value="Two Months">Two Months</option>
              <option value="Other / Not Sure">Other / Not Sure</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>9. Website Requirements</label>
          <textarea id="requirements" rows="3" placeholder="Key sections needed, design preferences..."></textarea>
        </div>
        <div class="form-group">
          <label>10. Additional Notes</label>
          <textarea id="notes" rows="2" placeholder="Reference links, logo info..."></textarea>
        </div>
        <button type="submit" class="btn btn-gold btn-block">Submit Order on WhatsApp</button>
      </form>
    </div>
  </section>

  <!-- CLOSING -->
  <section class="closing">
    <a href="#order" class="btn btn-gold btn-lg">Start Your Journey</a>
    <p class="script-tagline">Let's Create Something Extraordinary</p>
  </section>

  <footer class="footer">
    <div class="container footer-grid">
      <div class="footer-col">
        <span class="brand-title">DIGITAL SPARK</span>
        <span class="brand-sub">WEB AGENCY</span>
        <p class="footer-desc">DIGITAL SPARK WEB is a premier website design agency delivering high-speed, aesthetically refined static websites with luxury black-and-gold styling.</p>
      </div>
      <div class="footer-col">
        <h4>Navigation</h4>
        <ul style="list-style:none;">
          <li><a href="#home">Home</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#gallery">Demo Gallery</a></li>
          <li><a href="#pricing">Pricing</a></li>
          <li><a href="#order">Order</a></li>
        </ul>
      </div>
      <div class="footer-col">
        <h4>Contact Details</h4>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <a href="mailto:safyanjee82@gmail.com" class="btn btn-outline" style="text-align:left;text-transform:none;">
            Email: safyanjee82@gmail.com
          </a>
          <a href="tel:+923045768929" class="btn btn-outline" style="text-align:left;text-transform:none;">
            Call: +92 304 5768929
          </a>
          <a href="https://wa.me/message/OXDWP7NO5U7RI1" target="_blank" rel="noopener noreferrer" class="btn btn-gold" style="text-align:center;">
            Chat on WhatsApp
          </a>
          <a href="https://youtube.com/@digitalsparkwebwebsitedesign?si=nE8evWIFdmGnA4k2" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="text-align:left;text-transform:none;">
            YouTube: Digital Spark Web
          </a>
        </div>
      </div>
    </div>
    <div class="container" style="border-top:1px solid rgba(255,255,255,0.05);padding-top:20px;text-align:center;font-size:12px;color:#777;">
      <p>&copy; 2026 DIGITAL SPARK WEB. All rights reserved.</p>
    </div>
  </footer>

  <script src="script.js"></script>
</body>
</html>`;

      const cssContent = `:root {
  --bg-primary: #080808;
  --bg-secondary: #111111;
  --bg-card: #191919;
  --gold: #D9AD62;
  --gold-light: #F4D79B;
  --text-muted: #BDBDBD;
}
* { margin:0; padding:0; box-sizing:border-box; }
body { background: var(--bg-primary); color: var(--text-muted); font-family: 'Plus Jakarta Sans', sans-serif; line-height: 1.6; }
h1, h2, h3 { font-family: 'Cormorant Garamond', serif; color: #FFF; font-weight: 500; }
a { text-decoration: none; color: inherit; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
.header { position: fixed; top: 0; left: 0; right: 0; background: rgba(8,8,8,0.95); border-bottom: 1px solid rgba(217,173,98,0.2); padding: 15px 0; z-index: 100; }
.nav-container { display: flex; align-items: center; justify-content: space-between; }
.logo { display: flex; align-items: center; gap: 10px; }
.logo-icon { width: 36px; height: 36px; }
.brand-title { font-family: 'Cormorant Garamond', serif; font-size: 18px; font-weight: bold; color: #FFF; letter-spacing: 1px; display: block; }
.brand-sub { font-size: 9px; color: var(--gold); letter-spacing: 2px; }
.nav-links { display: flex; gap: 24px; font-size: 14px; }
.nav-links a:hover { color: var(--gold-light); }
.btn { display: inline-block; padding: 10px 22px; border-radius: 4px; font-size: 12px; font-weight: 600; text-transform: uppercase; cursor: pointer; transition: 0.3s; }
.btn-gold { background: linear-gradient(135deg, #F4D79B, #D9AD62, #B88939); color: #080808; border: none; }
.btn-gold:hover { filter: brightness(1.1); }
.btn-outline { border: 1px solid rgba(217,173,98,0.4); color: #FFF; background: transparent; }
.btn-outline:hover { background: rgba(217,173,98,0.1); border-color: var(--gold); }
.btn-sm { padding: 8px 14px; font-size: 11px; margin-top: 8px; width: 100%; text-align: center; }
.btn-lg { padding: 14px 32px; font-size: 14px; }
.btn-block { width: 100%; padding: 15px; font-size: 13px; }
.hero { padding: 160px 0 100px; text-align: center; }
.kicker { display: inline-block; padding: 4px 14px; border: 1px solid rgba(217,173,98,0.3); border-radius: 20px; font-size: 12px; color: var(--gold-light); margin-bottom: 20px; }
.hero h1 { font-size: 56px; line-height: 1.1; margin-bottom: 20px; }
.gold-text { color: var(--gold); }
.italic { font-style: italic; }
.gold-divider { display: flex; align-items: center; justify-content: center; width: 180px; height: 1px; background: linear-gradient(90deg, transparent, var(--gold), transparent); margin: 20px auto; position: relative; }
.diamond { width: 6px; height: 6px; background: var(--gold); transform: rotate(45deg); position: absolute; }
.tagline { color: var(--gold-light); font-size: 13px; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 15px; }
.desc { max-width: 650px; margin: 0 auto 35px; color: var(--text-muted); font-size: 16px; }
.hero-actions { display: flex; justify-content: center; gap: 15px; }
.section { padding: 80px 0; }
.section-title { text-align: center; margin-bottom: 50px; }
.section-title h2 { font-size: 38px; }
.grid { display: grid; gap: 24px; }
.grid-4 { grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); }
.grid-3 { grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); }
.card { background: var(--bg-card); border: 1px solid rgba(217,173,98,0.25); border-radius: 12px; padding: 25px; transition: 0.3s; }
.card:hover { border-color: rgba(217,173,98,0.6); }
.pricing-card { display: flex; flex-direction: column; justify-content: space-between; text-align: center; }
.price { font-size: 38px; font-family: 'Cormorant Garamond', serif; color: #FFF; font-weight: bold; margin: 15px 0; }
.features { list-style: none; text-align: left; margin: 20px 0 30px; font-size: 13px; }
.features li { padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
.features li::before { content: "✓ "; color: var(--gold); }
.featured-pkg { border: 2px solid var(--gold); position: relative; }
.badge { position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--gold); color: #000; font-size: 10px; font-weight: bold; padding: 2px 12px; border-radius: 10px; text-transform: uppercase; }
.order-form { max-width: 800px; margin: 0 auto; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
.form-group { margin-bottom: 18px; text-align: left; }
.form-group label { display: block; font-size: 12px; font-weight: 600; text-transform: uppercase; color: #E0E0E0; margin-bottom: 6px; }
.form-group input, .form-group select, .form-group textarea { width: 100%; background: #0D0D0D; border: 1px solid rgba(217,173,98,0.3); border-radius: 6px; padding: 12px; color: #FFF; font-family: inherit; font-size: 14px; outline: none; }
.closing { padding: 80px 0; text-align: center; background: #080808; border-top: 1px solid rgba(217,173,98,0.2); }
.script-tagline { font-family: 'Alex Brush', cursive; font-size: 42px; color: var(--gold-light); margin-top: 25px; }
.footer { background: #050505; border-top: 1px solid rgba(217,173,98,0.15); padding: 40px 0; text-align: center; font-size: 12px; color: #777; }
@media (max-width: 768px) {
  .nav-links { display: none; }
  .form-row { grid-template-columns: 1fr; }
  .hero h1 { font-size: 36px; }
}`;

      const jsContent = `function filterGallery(category) {
  const el = document.getElementById('gallery');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function selectOrderCategory(cat) {
  const select = document.getElementById('businessCategory');
  if (select) select.value = cat;
  const el = document.getElementById('order');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function selectPackage(name, price) {
  const select = document.getElementById('packageSelect');
  if (select) select.value = name;
  updatePrice();
  const el = document.getElementById('order');
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

function updatePrice() {
  const select = document.getElementById('packageSelect');
  const priceInput = document.getElementById('designPrice');
  if (select.value === 'Normal') priceInput.value = 'PKR 3,000';
  else if (select.value === 'Premium') priceInput.value = 'PKR 4,500';
  else priceInput.value = 'PKR 6,000';
}

function toggleDuration() {
  const pub = document.getElementById('publishingOption').value;
  const group = document.getElementById('durationGroup');
  group.style.display = (pub === 'I Need Live Publishing') ? 'block' : 'none';
}

function submitWhatsApp(e) {
  e.preventDefault();
  const name = document.getElementById('fullName').value;
  const phone = document.getElementById('whatsappNum').value;
  const business = document.getElementById('businessName').value;
  const category = document.getElementById('businessCategory').value;
  const pkg = document.getElementById('packageSelect').value;
  const price = document.getElementById('designPrice').value;
  const pub = document.getElementById('publishingOption').value;
  const duration = document.getElementById('publishingDuration') ? document.getElementById('publishingDuration').value : '';
  const req = document.getElementById('requirements').value;
  const notes = document.getElementById('notes').value;

  const msg = "*NEW WEBSITE PROJECT ORDER — DIGITAL SPARK WEB*\\n\\n" +
    "👤 *Client Name:* " + name + "\\n" +
    "📱 *WhatsApp:* " + phone + "\\n" +
    "🏢 *Business Name:* " + business + "\\n" +
    "🏷️ *Category:* " + category + "\\n\\n" +
    "📦 *Package:* " + pkg + " (" + price + ")\\n" +
    "🌐 *Publishing:* " + pub + "\\n" +
    (pub === 'I Need Live Publishing' ? ("⏱️ *Duration:* " + duration + "\\n") : "") +
    "\\n📝 *Requirements:*\\n" + (req || "Standard responsive website.") + "\\n\\n" +
    (notes ? ("📌 *Notes:*\\n" + notes) : "");

  const url = "https://wa.me/923045768929?text=" + encodeURIComponent(msg);
  window.open(url, '_blank');
}`;

      const readmeContent = `# DIGITAL SPARK WEB — Standalone Static Website Package

A luxury black-and-gold website design agency website for DIGITAL SPARK WEB.

## Included Files
- index.html: Complete semantic HTML5 structure
- style.css: Pure CSS3 styling with gold variables and responsive grids
- script.js: Vanilla JavaScript for gallery filters and WhatsApp message formatting

## How to Run
Simply open \`index.html\` in any web browser! No Node.js, build step, or server required.

## Deployment
Upload the folder directly to GitHub Pages, Netlify, Vercel, Hostinger, or any static hosting service.
`;

      if (folder) {
        folder.file('index.html', htmlContent);
        folder.file('style.css', cssContent);
        folder.file('script.js', jsContent);
        folder.file('README.md', readmeContent);
      }

      const blob = await zip.generateAsync({ type: 'blob' });
      const downloadUrl = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = 'digital-spark-web-static-package.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);
    } catch (err) {
      console.error(err);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-in fade-in">
      <div className="absolute inset-0" onClick={onClose} />
      <div className="relative w-full max-w-3xl bg-[#141414] border border-[#D9AD62]/40 rounded-2xl shadow-2xl z-10 text-white flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#D9AD62]/20">
          <div className="flex items-center gap-2">
            <FileCode className="w-5 h-5 text-[#D9AD62]" />
            <h3 className="font-serif-luxury text-xl font-normal text-white">
              Standalone Static Package (HTML/CSS/JS)
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-[#888] hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          <p className="text-sm text-[#CCCCCC] leading-relaxed">
            As requested in Section 4 of your project brief, you can download the 100% pure vanilla static website package (zero dependencies, zero build tools) ready to run instantly by double-clicking <code className="text-[#D9AD62]">index.html</code>.
          </p>

          <div className="bg-[#0a0a0a] rounded-xl p-4 border border-[#D9AD62]/20 text-xs font-mono text-[#D9AD62] space-y-1">
            <p>digital-spark-web/</p>
            <p>├── index.html   (Semantic HTML5 structure)</p>
            <p>├── style.css    (Luxury black & gold CSS3)</p>
            <p>├── script.js    (Vanilla JS WhatsApp router & filters)</p>
            <p>└── README.md    (Deployment instructions)</p>
          </div>

          <div className="p-4 rounded-xl bg-[#1a1a1a] border border-white/5 space-y-2">
            <p className="text-xs font-semibold text-[#F4D79B] uppercase tracking-wider">
              Package Features:
            </p>
            <ul className="text-xs text-[#AAA] space-y-1.5 list-disc list-inside">
              <li>Opens in any browser without terminal or installation</li>
              <li>Ready to deploy directly to Netlify, GitHub Pages, or Hostinger</li>
              <li>Complete WhatsApp order routing with customer form pre-filling</li>
              <li>Pure vanilla CSS with gold variables and responsive media queries</li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-[#D9AD62]/20 flex items-center justify-between gap-4 bg-[#0e0e0e] rounded-b-2xl">
          <span className="text-xs text-[#777]">ZIP archive with full source code</span>
          <button
            onClick={handleDownloadZip}
            disabled={downloading}
            className="gold-gradient-btn px-6 py-3 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4 text-[#080808]" />
            <span>{downloading ? 'Packaging ZIP...' : 'Download ZIP Package'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
