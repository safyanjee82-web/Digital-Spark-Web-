import React from 'react';
import { FileCode2, Clock, CheckCircle, MessageSquareCode } from 'lucide-react';

export const StatsBar: React.FC = () => {
  return (
    <div className="py-12 bg-[#0c0c0c] border-y border-[#D9AD62]/20 relative overflow-hidden">
      {/* Subtle ambient lighting */}
      <div className="absolute inset-0 bg-radial-gradient from-[#D9AD62]/5 to-transparent pointer-events-none" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-6 items-center">
          {/* Stat 1 */}
          <div className="flex items-center justify-center sm:justify-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#161616] border border-[#D9AD62]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(217,173,98,0.15)]">
              <FileCode2 className="w-6 h-6 text-[#D9AD62]" />
            </div>
            <div>
              <p className="font-serif-luxury text-3xl font-bold text-white tracking-tight tabular-nums">
                12+
              </p>
              <p className="text-xs uppercase font-medium text-[#BDBDBD] tracking-wider">
                Industry Concepts Ready
              </p>
            </div>
          </div>

          {/* Stat 2 */}
          <div className="flex items-center justify-center sm:justify-start gap-4 sm:border-l sm:border-[#D9AD62]/20 sm:pl-6">
            <div className="w-12 h-12 rounded-xl bg-[#161616] border border-[#D9AD62]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(217,173,98,0.15)]">
              <Clock className="w-6 h-6 text-[#D9AD62]" />
            </div>
            <div>
              <p className="font-serif-luxury text-3xl font-bold text-white tracking-tight tabular-nums">
                48 Hours
              </p>
              <p className="text-xs uppercase font-medium text-[#BDBDBD] tracking-wider">
                Rapid Project Turnaround
              </p>
            </div>
          </div>

          {/* Stat 3 */}
          <div className="flex items-center justify-center sm:justify-start gap-4 lg:border-l lg:border-[#D9AD62]/20 lg:pl-6">
            <div className="w-12 h-12 rounded-xl bg-[#161616] border border-[#D9AD62]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(217,173,98,0.15)]">
              <MessageSquareCode className="w-6 h-6 text-[#D9AD62]" />
            </div>
            <div>
              <p className="font-serif-luxury text-3xl font-bold text-white tracking-tight tabular-nums">
                100%
              </p>
              <p className="text-xs uppercase font-medium text-[#BDBDBD] tracking-wider">
                WhatsApp Integrated
              </p>
            </div>
          </div>

          {/* Stat 4 */}
          <div className="flex items-center justify-center sm:justify-start gap-4 lg:border-l lg:border-[#D9AD62]/20 lg:pl-6">
            <div className="w-12 h-12 rounded-xl bg-[#161616] border border-[#D9AD62]/40 flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(217,173,98,0.15)]">
              <CheckCircle className="w-6 h-6 text-[#D9AD62]" />
            </div>
            <div>
              <p className="font-serif-luxury text-3xl font-bold text-white tracking-tight tabular-nums">
                PKR 3,000+
              </p>
              <p className="text-xs uppercase font-medium text-[#BDBDBD] tracking-wider">
                Transparent Static Pricing
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
