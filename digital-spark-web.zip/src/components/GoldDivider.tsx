import React from 'react';

interface GoldDividerProps {
  className?: string;
  withDiamond?: boolean;
}

export const GoldDivider: React.FC<GoldDividerProps> = ({ className = '', withDiamond = true }) => {
  return (
    <div className={`relative flex items-center justify-center w-full max-w-md mx-auto my-6 ${className}`}>
      {/* Left gradient line */}
      <div className="flex-1 h-[1px] bg-gradient-to-r from-transparent via-[#D9AD62]/60 to-[#D9AD62]" />
      
      {/* Center ornament */}
      {withDiamond ? (
        <div className="relative mx-3 flex items-center justify-center">
          <div className="w-2 h-2 rotate-45 bg-[#D9AD62] shadow-[0_0_8px_#D9AD62]" />
          <div className="absolute w-1 h-1 rotate-45 bg-white" />
        </div>
      ) : (
        <div className="w-1.5 h-1.5 rounded-full bg-[#D9AD62] mx-3 shadow-[0_0_6px_#D9AD62]" />
      )}

      {/* Right gradient line */}
      <div className="flex-1 h-[1px] bg-gradient-to-l from-transparent via-[#D9AD62]/60 to-[#D9AD62]" />
    </div>
  );
};
