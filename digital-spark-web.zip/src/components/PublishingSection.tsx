import React from 'react';
import { GoldDivider } from './GoldDivider';
import { Globe, Server, Link2, Clock, MessageSquare, AlertCircle } from 'lucide-react';

interface PublishingSectionProps {
  onDiscussPublishing: () => void;
}

export const PublishingSection: React.FC<PublishingSectionProps> = ({ onDiscussPublishing }) => {
  return (
    <section id="publishing" className="py-20 md:py-28 bg-[#090909] relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Want Your Website Live?
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Already have a website design or need help publishing your new website online? Contact us to discuss suitable hosting and publishing options.
          </p>
        </div>

        {/* Informative Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Card 1 */}
          <div className="bg-[#141414] rounded-xl p-6 border border-[#D9AD62]/20 hover:border-[#D9AD62]/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-[#0d0d0d] border border-[#D9AD62]/30 flex items-center justify-center mb-4">
              <Server className="w-5 h-5 text-[#D9AD62]" />
            </div>
            <h3 className="font-serif-luxury text-lg text-white font-normal mb-2">
              Hosting Platform
            </h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed font-light">
              We help configure reputable static hosting or cloud hosting suited to your business traffic and budget.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-[#141414] rounded-xl p-6 border border-[#D9AD62]/20 hover:border-[#D9AD62]/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-[#0d0d0d] border border-[#D9AD62]/30 flex items-center justify-center mb-4">
              <Link2 className="w-5 h-5 text-[#D9AD62]" />
            </div>
            <h3 className="font-serif-luxury text-lg text-white font-normal mb-2">
              Domain Name (.com / .pk)
            </h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed font-light">
              Connect your existing business domain, or let us assist in acquiring a branded domain extension.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-[#141414] rounded-xl p-6 border border-[#D9AD62]/20 hover:border-[#D9AD62]/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-[#0d0d0d] border border-[#D9AD62]/30 flex items-center justify-center mb-4">
              <Clock className="w-5 h-5 text-[#D9AD62]" />
            </div>
            <h3 className="font-serif-luxury text-lg text-white font-normal mb-2">
              Project Duration
            </h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed font-light">
              From one month test campaigns to seasonal launches and permanent business hosting, we accommodate your schedule.
            </p>
          </div>

          {/* Card 4 */}
          <div className="bg-[#141414] rounded-xl p-6 border border-[#D9AD62]/20 hover:border-[#D9AD62]/50 transition-all">
            <div className="w-10 h-10 rounded-lg bg-[#0d0d0d] border border-[#D9AD62]/30 flex items-center justify-center mb-4">
              <Globe className="w-5 h-5 text-[#D9AD62]" />
            </div>
            <h3 className="font-serif-luxury text-lg text-white font-normal mb-2">
              SSL & Live Security
            </h3>
            <p className="text-xs text-[#A0A0A0] leading-relaxed font-light">
              Ensure your live website loads over secure HTTPS with valid encryption certificates and high accessibility.
            </p>
          </div>
        </div>

        {/* Quotation Notice Box */}
        <div className="bg-[#161616] border border-[#D9AD62]/30 rounded-2xl p-7 sm:p-8 max-w-3xl mx-auto shadow-[0_10px_35px_-10px_rgba(0,0,0,0.8)]">
          <div className="flex items-start gap-4 mb-6">
            <AlertCircle className="w-6 h-6 text-[#D9AD62] shrink-0 mt-0.5" />
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-white tracking-wide uppercase">
                Custom Quotation Required for Live Publishing
              </h4>
              <p className="text-xs sm:text-sm text-[#CCCCCC] leading-relaxed font-light">
                Publishing, hosting, and domain costs depend on your specific technical requirements, domain registrar fees, and expected visitor volume. A separate transparent quote will be provided before you confirm the service.
              </p>
            </div>
          </div>

          {/* CTA Button */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-[#D9AD62]/20">
            <span className="text-xs text-[#999999] text-center sm:text-left">
              Select your publishing preference in the project form below
            </span>
            <button
              onClick={onDiscussPublishing}
              className="gold-gradient-btn px-6 py-3 rounded text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer w-full sm:w-auto justify-center"
            >
              <MessageSquare className="w-4 h-4 text-[#080808]" />
              <span>Discuss Live Publishing</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
