import React from 'react';
import { MessageSquare, ExternalLink } from 'lucide-react';

export const FloatingWhatsApp: React.FC = () => {
  return (
    <aside
      aria-label="Direct WhatsApp contact"
      className="fixed bottom-6 right-6 z-40 flex items-center group select-none pointer-events-auto"
    >
      <a
        href="https://wa.me/message/OXDWP7NO5U7RI1"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat directly on WhatsApp with Digital Spark Web at +92 304 5768929"
        className="flex items-center gap-2.5 bg-[#0e0e0e]/95 hover:bg-[#161616] text-white border border-[#D9AD62]/60 hover:border-[#D9AD62] shadow-[0_8px_30px_rgba(217,173,98,0.35)] rounded-full px-4 py-3 sm:py-3.5 transition-all duration-300 hover:scale-105 active:scale-95"
      >
        {/* WhatsApp Icon with gold ambient indicator */}
        <div className="relative flex items-center justify-center">
          <div className="w-7 h-7 rounded-full bg-[#25D366]/20 border border-[#25D366]/50 flex items-center justify-center">
            <MessageSquare className="w-4 h-4 text-[#25D366] fill-[#25D366]" />
          </div>
          <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-[#D9AD62] animate-pulse" />
        </div>

        {/* Text Label on desktop / tablet */}
        <div className="flex flex-col text-left">
          <span className="text-[11px] font-bold uppercase tracking-wider text-[#F4D79B] leading-none">
            Chat on WhatsApp
          </span>
          <span className="text-[10px] text-[#A0A0A0] tabular-nums whitespace-nowrap mt-0.5 font-mono">
            +92 304 5768929
          </span>
        </div>

        <ExternalLink className="w-3.5 h-3.5 text-[#D9AD62] opacity-70 group-hover:opacity-100 transition-opacity ml-1 shrink-0" />
      </a>
    </aside>
  );
};
