import React from 'react';
import { GoldDivider } from './GoldDivider';
import { PRICING_PACKAGES, PricingPackage } from '../data/mockData';
import { Check, ShieldCheck, Sparkles } from 'lucide-react';

interface PricingProps {
  onSelectPackage: (pkg: PricingPackage) => void;
  selectedPackageId?: string;
}

export const Pricing: React.FC<PricingProps> = ({ onSelectPackage, selectedPackageId }) => {
  return (
    <section id="pricing" className="py-20 md:py-28 bg-[#0d0d0d] relative">
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#D9AD62]/5 blur-[120px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Choose Your Website Package
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Select the website design package that best fits your needs. Transparent, fixed pricing with zero hidden subscription traps.
          </p>
        </div>

        {/* 3 Pricing Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch max-w-6xl mx-auto">
          {PRICING_PACKAGES.map((pkg) => {
            const isSelected = selectedPackageId === pkg.id;
            const isBusiness = pkg.id === 'business';

            return (
              <div
                key={pkg.id}
                className={`relative rounded-2xl p-7 sm:p-8 flex flex-col justify-between transition-all duration-300 ${
                  isBusiness
                    ? 'bg-[#181818] border-2 border-[#D9AD62] shadow-[0_15px_40px_-5px_rgba(217,173,98,0.25)] lg:-translate-y-2'
                    : 'bg-[#131313] border border-[#D9AD62]/25 hover:border-[#D9AD62]/50 shadow-[0_10px_30px_-8px_rgba(0,0,0,0.7)]'
                }`}
              >
                {/* Popular Highlight Badge for Business package */}
                {isBusiness && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#D9AD62] text-[#080808] px-4 py-1 rounded-full text-[11px] font-bold uppercase tracking-widest flex items-center gap-1.5 shadow-md">
                    <Sparkles className="w-3.5 h-3.5 fill-[#080808]" />
                    <span>Recommended · Most Comprehensive</span>
                  </div>
                )}

                <div>
                  {/* Package Name */}
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-serif-luxury text-2xl font-bold tracking-wider text-[#F4D79B]">
                      {pkg.name}
                    </h3>
                    {isSelected && (
                      <span className="text-[10px] font-semibold text-[#D9AD62] border border-[#D9AD62] px-2 py-0.5 rounded">
                        Selected
                      </span>
                    )}
                  </div>

                  {/* Price */}
                  <div className="mb-4">
                    <div className="flex items-baseline gap-1">
                      <span className="font-serif-luxury text-4xl sm:text-5xl font-bold text-white tracking-tight tabular-nums">
                        {pkg.formattedPrice}
                      </span>
                    </div>
                    <p className="text-[11px] text-[#A0A0A0] mt-1 font-light">
                      One-time website design price · No monthly design fee
                    </p>
                  </div>

                  {/* Description */}
                  <p className="text-xs sm:text-sm text-[#CCCCCC] leading-relaxed mb-6 font-light border-b border-[#D9AD62]/15 pb-5">
                    {pkg.description}
                  </p>

                  {/* Feature List */}
                  <div className="space-y-3 mb-8">
                    <p className="text-xs font-semibold text-[#F4D79B] uppercase tracking-wider">
                      Included In This Package:
                    </p>
                    <ul className="space-y-2.5 text-xs text-[#BDBDBD]">
                      {pkg.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2.5">
                          <Check className="w-4 h-4 text-[#D9AD62] shrink-0 mt-0.5" />
                          <span className="leading-snug">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Package Button */}
                <div className="pt-4 border-t border-[#D9AD62]/15">
                  <button
                    onClick={() => onSelectPackage(pkg)}
                    className={`w-full py-3.5 rounded text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                      isBusiness || isSelected
                        ? 'gold-gradient-btn'
                        : 'bg-[#222222] hover:bg-[#2a2a2a] text-[#F4D79B] border border-[#D9AD62]/40 hover:border-[#D9AD62]'
                    }`}
                  >
                    {`Choose ${pkg.name.charAt(0) + pkg.name.slice(1).toLowerCase()}`}
                  </button>
                  <p className="text-[10px] text-center text-[#7A7A7A] mt-2">
                    Pre-selects this package in your project order form
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Pricing Honesty Banner */}
        <div className="mt-14 max-w-4xl mx-auto rounded-xl p-5 bg-[#121212] border border-[#D9AD62]/20 text-xs text-[#A0A0A0] leading-relaxed flex items-start gap-3.5">
          <ShieldCheck className="w-5 h-5 text-[#D9AD62] shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-white mb-1">
              Transparent Website Scope & Honest Guarantees
            </p>
            <p>
              The prices listed above (PKR 3,000 / PKR 4,500 / PKR 6,000) cover complete, responsive static website frontend design delivered in pure HTML, CSS, and JavaScript. They do not automatically include third-party domain purchases, hosting servers, or custom backend databases/payment gateways. Live hosting and domain publishing can be discussed separately if desired.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
