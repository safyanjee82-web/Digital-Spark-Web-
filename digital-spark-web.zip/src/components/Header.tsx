import React, { useState, useEffect } from 'react';
import { Logo } from './Logo';
import { Menu, X, ArrowUpRight } from 'lucide-react';

interface HeaderProps {
  onOrderClick: () => void;
  onExportClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOrderClick, onExportClick }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#080808]/95 backdrop-blur-md border-b border-[#D9AD62]/20 py-3 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.8)]'
          : 'bg-gradient-to-b from-[#080808]/90 via-[#080808]/60 to-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            scrollToSection('home');
          }}
          className="whitespace-nowrap shrink-0 group focus:outline-none"
        >
          <Logo size="md" />
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-[#BDBDBD]">
          <button
            onClick={() => scrollToSection('home')}
            className="hover:text-[#F4D79B] transition-colors whitespace-nowrap shrink-0 cursor-pointer text-sm font-medium"
          >
            Home
          </button>
          <button
            onClick={() => scrollToSection('services')}
            className="hover:text-[#F4D79B] transition-colors whitespace-nowrap shrink-0 cursor-pointer text-sm font-medium"
          >
            Services
          </button>
          <button
            onClick={() => scrollToSection('gallery')}
            className="hover:text-[#F4D79B] transition-colors whitespace-nowrap shrink-0 cursor-pointer text-sm font-medium"
          >
            Demo Gallery
          </button>
          <button
            onClick={() => scrollToSection('pricing')}
            className="hover:text-[#F4D79B] transition-colors whitespace-nowrap shrink-0 cursor-pointer text-sm font-medium"
          >
            Pricing
          </button>
          <button
            onClick={() => scrollToSection('order-form')}
            className="hover:text-[#F4D79B] transition-colors whitespace-nowrap shrink-0 cursor-pointer text-sm font-medium"
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="hidden md:flex items-center gap-4 shrink-0">
          {onExportClick && (
            <button
              onClick={onExportClick}
              className="text-xs text-[#D9AD62] border border-[#D9AD62]/30 px-3 py-2 rounded hover:border-[#D9AD62] hover:bg-[#D9AD62]/10 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-1.5"
              title="Inspect or download static website code package"
            >
              <span>Static Package</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            onClick={onOrderClick}
            className="gold-gradient-btn px-5 py-2.5 rounded text-xs font-semibold uppercase tracking-wider whitespace-nowrap cursor-pointer"
          >
            Order a Website
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#D9AD62] hover:text-white rounded-lg focus:outline-none cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#111111] border-b border-[#D9AD62]/30 px-5 py-6 space-y-4 animate-in slide-in-from-top-2">
          <nav className="flex flex-col space-y-3 text-sm font-medium">
            <button
              onClick={() => scrollToSection('home')}
              className="text-left text-white hover:text-[#D9AD62] py-2 border-b border-white/5 cursor-pointer"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection('services')}
              className="text-left text-white hover:text-[#D9AD62] py-2 border-b border-white/5 cursor-pointer"
            >
              Services
            </button>
            <button
              onClick={() => scrollToSection('gallery')}
              className="text-left text-white hover:text-[#D9AD62] py-2 border-b border-white/5 cursor-pointer"
            >
              Demo Gallery
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="text-left text-white hover:text-[#D9AD62] py-2 border-b border-white/5 cursor-pointer"
            >
              Website Packages
            </button>
            <button
              onClick={() => scrollToSection('publishing')}
              className="text-left text-white hover:text-[#D9AD62] py-2 border-b border-white/5 cursor-pointer"
            >
              Live Publishing
            </button>
            <button
              onClick={() => scrollToSection('order-form')}
              className="text-left text-white hover:text-[#D9AD62] py-2 cursor-pointer"
            >
              Order & Inquiries
            </button>
          </nav>

          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOrderClick();
              }}
              className="w-full gold-gradient-btn py-3 rounded text-center text-xs font-semibold uppercase tracking-wider"
            >
              Order a Website
            </button>
            {onExportClick && (
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onExportClick();
                }}
                className="w-full py-2.5 text-center text-xs text-[#D9AD62] border border-[#D9AD62]/30 rounded hover:bg-[#D9AD62]/10"
              >
                Download Static Files (ZIP)
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
