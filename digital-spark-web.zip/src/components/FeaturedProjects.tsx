import React from 'react';
import { GoldDivider } from './GoldDivider';
import { FEATURED_CONCEPTS } from '../data/mockData';
import { ArrowUpRight } from 'lucide-react';

interface FeaturedProjectsProps {
  onExploreConcept: (category: string) => void;
}

export const FeaturedProjects: React.FC<FeaturedProjectsProps> = ({ onExploreConcept }) => {
  return (
    <section id="featured" className="py-20 md:py-28 bg-[#080808] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Featured Website Concepts
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Selected showcase demonstrations highlighting the depth, composition, and visual sophistication of our work.
          </p>
        </div>

        {/* 3 Large Photographic Cards Grid matching reference image */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {FEATURED_CONCEPTS.map((concept) => (
            <div
              key={concept.id}
              className="group relative bg-[#131313] rounded-2xl overflow-hidden border border-[#D9AD62]/25 hover:border-[#D9AD62]/70 transition-all duration-500 shadow-[0_15px_35px_-10px_rgba(0,0,0,0.8)] flex flex-col justify-between"
            >
              {/* Image Frame with hover zoom */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-[#1c1c1c]">
                <img
                  src={concept.image}
                  alt={concept.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                {/* Dark gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#131313] via-transparent to-black/20" />

                {/* Subtle top gold badge */}
                <div className="absolute top-3.5 left-3.5 px-3 py-1 rounded bg-[#0a0a0a]/80 backdrop-blur-md border border-[#D9AD62]/30 text-[10px] uppercase font-semibold text-[#F4D79B] tracking-wider">
                  Featured Concept
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-serif-luxury text-2xl font-normal text-white group-hover:text-[#F4D79B] transition-colors mb-1.5">
                    {concept.title}
                  </h3>
                  <p className="text-xs uppercase font-medium text-[#D9AD62] tracking-wider mb-3">
                    {concept.tagline}
                  </p>
                  <p className="text-xs sm:text-sm text-[#A0A0A0] leading-relaxed mb-6 font-light">
                    {concept.description}
                  </p>
                </div>

                {/* Fine gold decorative line and button */}
                <div className="pt-4 border-t border-[#D9AD62]/20 flex items-center justify-between">
                  <span className="text-[11px] text-[#7E7E7E]">Static Frontend Concept</span>
                  <button
                    onClick={() => onExploreConcept(concept.category)}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#F4D79B] hover:text-white transition-colors cursor-pointer group-hover:translate-x-1 duration-300"
                  >
                    <span>Explore Design</span>
                    <ArrowUpRight className="w-4 h-4 text-[#D9AD62]" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
