import React, { useState, useEffect } from 'react';
import { GoldDivider } from './GoldDivider';
import { PRICING_PACKAGES } from '../data/mockData';
import { Send, Copy, Check, MessageSquare, AlertCircle, Sparkles, Phone, ExternalLink, ShieldCheck } from 'lucide-react';

interface OrderFormProps {
  initialCategory?: string;
  initialPackage?: string;
  initialPublishing?: string;
}

const CATEGORIES = [
  'Restaurant',
  'Online Shopping',
  'Real Estate',
  'Interior Design',
  'Hotel and Travel',
  'Beauty Salon',
  'Corporate Business',
  'Personal Portfolio',
  'Fitness and Gym',
  'Construction',
  'Education',
  'Medical Clinic',
  'Other',
];

// Business recipient WhatsApp phone number
const BUSINESS_WHATSAPP_NUMBER = '923045768929';
const BUSINESS_DISPLAY_PHONE = '+92 304 5768929';
const DIRECT_WHATSAPP_LINK = 'https://wa.me/message/OXDWP7NO5U7RI1';

export const OrderForm: React.FC<OrderFormProps> = ({
  initialCategory,
  initialPackage,
  initialPublishing,
}) => {
  const [fullName, setFullName] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [category, setCategory] = useState(initialCategory || 'Corporate Business');
  const [selectedPackage, setSelectedPackage] = useState<'normal' | 'premium' | 'business'>(
    (initialPackage as 'normal' | 'premium' | 'business') || 'business'
  );
  const [publishing, setPublishing] = useState<string>(initialPublishing || 'Website Design Only');
  const [duration, setDuration] = useState<string>('Other / Not Sure');
  const [requirements, setRequirements] = useState('');
  const [additionalNotes, setAdditionalNotes] = useState('');

  const [copied, setCopied] = useState(false);
  const [openedWhatsApp, setOpenedWhatsApp] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [fieldErrors, setFieldErrors] = useState<{ name?: boolean; phone?: boolean; business?: boolean }>({});

  // Sync prop changes
  useEffect(() => {
    if (initialCategory) setCategory(initialCategory);
  }, [initialCategory]);

  useEffect(() => {
    if (initialPackage && (initialPackage === 'normal' || initialPackage === 'premium' || initialPackage === 'business')) {
      setSelectedPackage(initialPackage);
    }
  }, [initialPackage]);

  useEffect(() => {
    if (initialPublishing) setPublishing(initialPublishing);
  }, [initialPublishing]);

  const currentPkg = PRICING_PACKAGES.find((p) => p.id === selectedPackage) || PRICING_PACKAGES[2];

  // Build structured message strictly for the business owner
  const buildWhatsAppMessage = () => {
    return (
      `*NEW WEBSITE PROJECT ORDER — DIGITAL SPARK WEB*\n\n` +
      `👤 *Customer Name:* ${fullName.trim()}\n` +
      `📱 *Customer Contact (WhatsApp):* ${whatsappNumber.trim()}\n` +
      `🏢 *Business Name:* ${businessName.trim()}\n` +
      `🏷️ *Business Type / Category:* ${category}\n\n` +
      `📦 *Selected Package:* ${currentPkg.name}\n` +
      `💰 *Package Price:* ${currentPkg.formattedPrice} (One-Time Design)\n\n` +
      `🌐 *Publishing Requirement:* ${publishing}\n` +
      (publishing === 'I Need Live Publishing' ? `⏱️ *Preferred Duration:* ${duration}\n` : '') +
      `\n📝 *Project Requirements:*\n${requirements.trim() || 'Standard business layout with responsive pages and contact integration.'}\n\n` +
      (additionalNotes.trim() ? `📌 *Additional Notes:*\n${additionalNotes.trim()}\n\n` : '') +
      `---\n*Sent to Digital Spark Web (${BUSINESS_DISPLAY_PHONE}) via Website Order Portal*`
    );
  };

  const handleCopySummary = async () => {
    const text = buildWhatsAppMessage();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // Fallback
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const errors: { name?: boolean; phone?: boolean; business?: boolean } = {};
    if (!fullName.trim()) errors.name = true;
    if (!whatsappNumber.trim()) errors.phone = true;
    if (!businessName.trim()) errors.business = true;

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      setErrorMsg('Please fill in your name, WhatsApp number, and business name to proceed.');
      return;
    }

    setFieldErrors({});
    setErrorMsg('');

    // Pre-format message and build WhatsApp URL strictly to business number 923045768929
    const rawMsg = buildWhatsAppMessage();
    const encoded = encodeURIComponent(rawMsg);
    const whatsappUrl = `https://wa.me/${BUSINESS_WHATSAPP_NUMBER}?text=${encoded}`;

    // Open WhatsApp addressed to business owner
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
    setOpenedWhatsApp(true);
  };

  return (
    <section id="order-form" className="py-20 md:py-28 bg-[#0b0b0b] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full border border-[#D9AD62]/30 bg-[#141414] text-[#F4D79B] text-xs font-medium tracking-wide mb-3">
            <Sparkles className="w-3.5 h-3.5 text-[#D9AD62]" />
            <span>Direct WhatsApp Order Integration</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-5xl font-light text-white tracking-tight">
            Start Your Website Project
          </h2>
          <GoldDivider />
          <p className="text-sm sm:text-base text-[#BDBDBD] font-light">
            Tell us about your business and select the website design package you need. Review all project details in the live summary and submit directly to our business WhatsApp at{' '}
            <span className="text-[#F4D79B] font-medium tabular-nums whitespace-nowrap">
              {BUSINESS_DISPLAY_PHONE}
            </span>.
          </p>
        </div>

        {/* Status notification banner after customer clicks submit (non-destructive, zero layout shift) */}
        {openedWhatsApp && (
          <div className="max-w-4xl mx-auto mb-8 p-5 rounded-xl bg-[#141414] border-2 border-[#D9AD62] shadow-[0_10px_35px_rgba(217,173,98,0.25)] flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in">
            <div className="flex items-start gap-3.5">
              <div className="w-9 h-9 rounded-full bg-[#D9AD62]/20 border border-[#D9AD62] flex items-center justify-center shrink-0 mt-0.5">
                <Send className="w-4 h-4 text-[#D9AD62]" />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">
                  WhatsApp Chat Prepared with Business Number ({BUSINESS_DISPLAY_PHONE})
                </p>
                <p className="text-xs text-[#BDBDBD] font-light mt-0.5">
                  Please review the pre-filled message in WhatsApp and press <span className="text-[#F4D79B] font-semibold">"Send"</span> to submit your project requirements to Digital Spark Web.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  const encoded = encodeURIComponent(buildWhatsAppMessage());
                  window.open(`https://wa.me/${BUSINESS_WHATSAPP_NUMBER}?text=${encoded}`, '_blank');
                }}
                className="gold-gradient-btn px-4 py-2 rounded text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer w-full sm:w-auto"
              >
                <Send className="w-3.5 h-3.5 text-[#080808]" />
                <span>Re-open WhatsApp</span>
              </button>
              <button
                type="button"
                onClick={handleCopySummary}
                className="px-3 py-2 rounded text-xs font-medium text-white border border-[#D9AD62]/40 hover:bg-[#D9AD62]/10 transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-[#D9AD62]" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Complete 10-Field Order Form (7 cols on lg+) */}
          <form
            onSubmit={handleSubmit}
            noValidate
            className="lg:col-span-7 bg-[#131313] border border-[#D9AD62]/25 rounded-2xl p-6 sm:p-8 shadow-2xl space-y-6"
          >
            {/* Validation Alert (min-height prevents layout jump) */}
            {errorMsg ? (
              <div className="p-3.5 rounded-lg bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{errorMsg}</span>
              </div>
            ) : null}

            {/* Row 1: Full Name & Customer WhatsApp Number */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                  1. Your Full Name <span className="text-[#D9AD62]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Tariq Mehmood"
                  value={fullName}
                  onChange={(e) => {
                    setFullName(e.target.value);
                    if (fieldErrors.name) setFieldErrors({ ...fieldErrors, name: false });
                  }}
                  className={`w-full bg-[#0d0d0d] border ${
                    fieldErrors.name ? 'border-red-500/80 ring-1 ring-red-500/40' : 'border-[#D9AD62]/30'
                  } focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white placeholder-[#666666] outline-none transition-colors`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                  2. Your WhatsApp Number <span className="text-[#D9AD62]">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +92 300 1234567"
                  value={whatsappNumber}
                  onChange={(e) => {
                    setWhatsappNumber(e.target.value);
                    if (fieldErrors.phone) setFieldErrors({ ...fieldErrors, phone: false });
                  }}
                  className={`w-full bg-[#0d0d0d] border ${
                    fieldErrors.phone ? 'border-red-500/80 ring-1 ring-red-500/40' : 'border-[#D9AD62]/30'
                  } focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white placeholder-[#666666] outline-none transition-colors`}
                />
              </div>
            </div>

            {/* Row 2: Business Name & Business Type / Category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                  3. Business / Brand Name <span className="text-[#D9AD62]">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Royal Taste Lounge"
                  value={businessName}
                  onChange={(e) => {
                    setBusinessName(e.target.value);
                    if (fieldErrors.business) setFieldErrors({ ...fieldErrors, business: false });
                  }}
                  className={`w-full bg-[#0d0d0d] border ${
                    fieldErrors.business ? 'border-red-500/80 ring-1 ring-red-500/40' : 'border-[#D9AD62]/30'
                  } focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white placeholder-[#666666] outline-none transition-colors`}
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                  4. Business Type / Category <span className="text-[#D9AD62]">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#D9AD62]/30 focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white outline-none transition-colors cursor-pointer"
                >
                  {CATEGORIES.map((cat) => (
                    <option key={cat} value={cat} className="bg-[#141414] text-white">
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Row 3: Website Package Selection */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0]">
                  5. Selected Website Package <span className="text-[#D9AD62]">*</span>
                </label>
                <span className="text-[11px] text-[#A0A0A0]">One-time design deliverables</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {PRICING_PACKAGES.map((pkg) => (
                  <label
                    key={pkg.id}
                    className={`relative flex flex-col p-4 rounded-xl border cursor-pointer transition-all ${
                      selectedPackage === pkg.id
                        ? 'bg-[#1e1e1e] border-[#D9AD62] shadow-[0_0_15px_rgba(217,173,98,0.2)]'
                        : 'bg-[#0d0d0d] border-[#D9AD62]/20 hover:border-[#D9AD62]/40'
                    }`}
                  >
                    <input
                      type="radio"
                      name="package"
                      value={pkg.id}
                      checked={selectedPackage === pkg.id}
                      onChange={() => setSelectedPackage(pkg.id)}
                      className="sr-only"
                    />
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-serif-luxury text-base font-bold text-white">
                        {pkg.name}
                      </span>
                      <div
                        className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 ${
                          selectedPackage === pkg.id
                            ? 'border-[#D9AD62] bg-[#D9AD62]'
                            : 'border-white/20'
                        }`}
                      >
                        {selectedPackage === pkg.id && (
                          <div className="w-1.5 h-1.5 rounded-full bg-[#080808]" />
                        )}
                      </div>
                    </div>
                    <span className="text-sm font-semibold text-[#D9AD62] tabular-nums">
                      {pkg.formattedPrice}
                    </span>
                    <span className="text-[10px] text-[#888888] mt-1 leading-tight line-clamp-2">
                      {pkg.description}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Row 4: Publishing Requirement */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                  6. Publishing Requirement <span className="text-[#D9AD62]">*</span>
                </label>
                <select
                  value={publishing}
                  onChange={(e) => setPublishing(e.target.value)}
                  className="w-full bg-[#0d0d0d] border border-[#D9AD62]/30 focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white outline-none transition-colors cursor-pointer"
                >
                  <option value="Website Design Only" className="bg-[#141414] text-white">
                    1. Website Design Only (Code delivery)
                  </option>
                  <option value="I Need Live Publishing" className="bg-[#141414] text-white">
                    2. I Need Live Publishing (Hosting / Domain setup)
                  </option>
                  <option value="I Need Advice" className="bg-[#141414] text-white">
                    3. I Need Advice (Discuss options)
                  </option>
                </select>
              </div>

              <div>
                {publishing === 'I Need Live Publishing' ? (
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                      7. Preferred Publishing Duration
                    </label>
                    <select
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="w-full bg-[#0d0d0d] border border-[#D9AD62]/30 focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white outline-none transition-colors cursor-pointer"
                    >
                      <option value="One Month" className="bg-[#141414] text-white">
                        One Month (Campaign / Initial Test)
                      </option>
                      <option value="Two Months" className="bg-[#141414] text-white">
                        Two Months
                      </option>
                      <option value="Other / Not Sure" className="bg-[#141414] text-white">
                        Other / Permanent / Not Sure
                      </option>
                    </select>
                  </div>
                ) : (
                  <div className="flex flex-col justify-end h-full">
                    <p className="text-[11px] text-[#888888] italic py-3">
                      Complete source files (HTML5, CSS3, JS) ready for your own host.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Row 5: Project Requirements */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                8. Project Requirements & Pages Needed
              </label>
              <textarea
                rows={3}
                placeholder="Describe your desired pages (e.g. Home, Services, Menu, Gallery), design taste, or project goals..."
                value={requirements}
                onChange={(e) => setRequirements(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-[#D9AD62]/30 focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white placeholder-[#666666] outline-none transition-colors"
              />
            </div>

            {/* Row 6: Additional Notes */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-[#E0E0E0] mb-2">
                9. Additional Notes & Reference Websites
              </label>
              <textarea
                rows={2}
                placeholder="Any existing logos, reference websites you like, or special requests..."
                value={additionalNotes}
                onChange={(e) => setAdditionalNotes(e.target.value)}
                className="w-full bg-[#0d0d0d] border border-[#D9AD62]/30 focus:border-[#D9AD62] focus:ring-1 focus:ring-[#D9AD62] rounded-lg px-4 py-3 text-sm text-white placeholder-[#666666] outline-none transition-colors"
              />
            </div>

            {/* Primary Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center gap-4">
              <button
                type="submit"
                className="w-full sm:flex-1 gold-gradient-btn py-4 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 cursor-pointer shadow-lg hover:scale-[1.01] transition-transform"
              >
                <MessageSquare className="w-4 h-4 text-[#080808]" />
                <span>Submit Order on WhatsApp</span>
              </button>

              <button
                type="button"
                onClick={handleCopySummary}
                className="w-full sm:w-auto px-5 py-4 rounded-xl text-xs font-medium text-white border border-[#D9AD62]/35 hover:bg-[#D9AD62]/10 transition-colors flex items-center justify-center gap-2 cursor-pointer shrink-0"
              >
                {copied ? <Check className="w-4 h-4 text-[#D9AD62]" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Summary Copied' : 'Copy Summary'}</span>
              </button>
            </div>

            {/* Reassurance text */}
            <p className="text-[11px] text-[#7A7A7A] text-center pt-1">
              Your details will be pre-filled into a WhatsApp message addressed to Digital Spark Web ({BUSINESS_DISPLAY_PHONE}). You will only need to press "Send".
            </p>
          </form>

          {/* Right Column: Live Order Summary & Direct Contact (5 cols on lg+) */}
          <div className="lg:col-span-5 space-y-6">
            {/* Live Order Review Card */}
            <div className="bg-[#141414] border border-[#D9AD62]/35 rounded-2xl p-6 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between mb-4 border-b border-[#D9AD62]/20 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#D9AD62]" />
                  <h3 className="font-serif-luxury text-xl font-bold text-white">
                    Live Order Summary
                  </h3>
                </div>
                <span className="text-[10px] uppercase font-semibold text-[#D9AD62] border border-[#D9AD62]/30 px-2 py-0.5 rounded">
                  Review Details
                </span>
              </div>

              <div className="space-y-3 text-xs text-[#CCCCCC]">
                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Customer Name:</span>
                  <span className="font-medium text-white truncate max-w-[180px]">
                    {fullName.trim() || <span className="text-[#666666] italic">Not entered yet</span>}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Customer WhatsApp:</span>
                  <span className="font-medium text-white tabular-nums truncate max-w-[180px]">
                    {whatsappNumber.trim() || <span className="text-[#666666] italic">Not entered yet</span>}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Business Name:</span>
                  <span className="font-medium text-white truncate max-w-[180px]">
                    {businessName.trim() || <span className="text-[#666666] italic">Not entered yet</span>}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Business Type:</span>
                  <span className="text-white truncate max-w-[180px]">{category}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Package:</span>
                  <span className="font-bold text-[#F4D79B] uppercase tracking-wider">{currentPkg.name}</span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Package Price:</span>
                  <span className="font-bold text-[#D9AD62] text-sm tabular-nums">
                    {currentPkg.formattedPrice}
                  </span>
                </div>

                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[#888888]">Publishing Choice:</span>
                  <span className="text-white truncate max-w-[180px]">{publishing}</span>
                </div>

                {publishing === 'I Need Live Publishing' && (
                  <div className="flex justify-between items-center py-1 border-b border-white/5">
                    <span className="text-[#888888]">Duration Pref:</span>
                    <span className="text-white">{duration}</span>
                  </div>
                )}
              </div>

              {/* Subtotal block */}
              <div className="pt-4 mt-3 border-t border-[#D9AD62]/20 flex items-baseline justify-between">
                <div>
                  <p className="text-[11px] uppercase font-semibold text-[#888888]">Total Design Price:</p>
                  <p className="text-[10px] text-[#7A7A7A]">One-time fixed design fee</p>
                </div>
                <span className="font-serif-luxury text-2xl font-bold text-[#F4D79B] tabular-nums">
                  {currentPkg.formattedPrice}
                </span>
              </div>

              {/* Submit CTA right from summary card */}
              <div className="mt-5 pt-4 border-t border-white/10">
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="w-full gold-gradient-btn py-3.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <MessageSquare className="w-4 h-4 text-[#080808]" />
                  <span>Submit Order on WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Designated Business WhatsApp Info Card (Strictly fixed position, zero layout shift) */}
            <div className="bg-[#111111] border border-[#D9AD62]/25 rounded-2xl p-6 text-xs space-y-4">
              <div className="flex items-center justify-between text-[#D9AD62]">
                <div className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-[#D9AD62] shrink-0" />
                  <span className="font-semibold uppercase tracking-wider text-[11px]">
                    Designated Business Number
                  </span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-[#7A7A7A]">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#D9AD62]" />
                  <span>Verified Recipient</span>
                </div>
              </div>

              {/* Fixed WhatsApp phone number display with phone icon */}
              <div className="flex items-center justify-between p-3.5 rounded-xl bg-[#090909] border border-[#D9AD62]/20">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#D9AD62]/10 border border-[#D9AD62]/30 flex items-center justify-center">
                    <MessageSquare className="w-3.5 h-3.5 text-[#D9AD62]" />
                  </div>
                  <div>
                    <p className="text-[10px] text-[#888888] uppercase">WhatsApp & Call</p>
                    <p className="text-sm font-bold text-white tracking-wide font-mono tabular-nums whitespace-nowrap">
                      {BUSINESS_DISPLAY_PHONE}
                    </p>
                  </div>
                </div>
                <a
                  href={`tel:${BUSINESS_DISPLAY_PHONE.replace(/[^0-9+]/g, '')}`}
                  className="text-xs text-[#D9AD62] hover:text-white border border-[#D9AD62]/40 hover:border-[#D9AD62] px-2.5 py-1.5 rounded transition-colors whitespace-nowrap"
                  title="Direct Phone Call"
                >
                  Call Now
                </a>
              </div>

              <p className="text-[#A0A0A0] text-[11px] leading-relaxed">
                All order submissions are pre-addressed directly to our business WhatsApp (<span className="text-white font-mono">{BUSINESS_WHATSAPP_NUMBER}</span>).
              </p>

              {/* Separate direct WhatsApp chat button without filling form */}
              <div className="pt-2 border-t border-white/5 space-y-2">
                <p className="text-[11px] text-[#888888] font-medium">
                  Have a quick question without submitting an order?
                </p>
                <a
                  href={DIRECT_WHATSAPP_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-[#181818] hover:bg-[#202020] border border-[#D9AD62]/35 hover:border-[#D9AD62] text-[#F4D79B] flex items-center justify-center gap-2 text-xs font-semibold uppercase tracking-wider transition-all"
                >
                  <MessageSquare className="w-4 h-4 text-[#D9AD62]" />
                  <span>Quick WhatsApp Chat</span>
                  <ExternalLink className="w-3.5 h-3.5 text-[#888888]" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
